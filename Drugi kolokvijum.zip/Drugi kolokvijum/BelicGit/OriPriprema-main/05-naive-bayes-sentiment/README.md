## Vežba 5 - Nadgledano učenje - Naivni Bayes

Otvoriti datoteku **05-naive-bayes-sentiment.ipynb**.
