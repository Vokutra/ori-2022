﻿## Uputstvo za dodatne zadatke

Ukoliko rešite neki od dodatnih zadataka, napravite Pull Request koji će u sebi sadržati sledeće:

* Python skriptu - poželjno jedan fajl sa smislenim imenom.
Na početku fajla u komentaru napisati ko je autor i koji zadatak je rešen
* Data set (podatke) - u csv/tsv/txt formatu, a ime da bude isto kao ime Python skripte
* Oba prethodna fajla staviti u ovaj folder - **bonus**

