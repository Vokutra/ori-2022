# TODO 4: implementirati primenu visestruke linearne regresije
# nad podacima iz datoteke "data/iq.tsv".
# Korisiti implementaciju linearne regresije u alatu scikit-learn
