## Vežba 4 - Linearna regresija

Otvoriti datoteku **04-linreg.ipynb**.
