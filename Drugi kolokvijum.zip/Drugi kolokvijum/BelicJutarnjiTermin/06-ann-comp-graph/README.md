## Vežba 6 - Uvod u veštačke neuronske mreže - graf izračunavanja

Otvoriti datoteku **06-ann-comp-graph.ipynb**.
