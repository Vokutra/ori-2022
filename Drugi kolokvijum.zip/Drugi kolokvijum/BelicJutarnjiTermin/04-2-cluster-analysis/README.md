## Vežba 4 - Nenadgledano učenje - klasterizacija

Otvoriti datoteku **04-2-cluster-analysis.ipynb**.
