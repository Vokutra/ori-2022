﻿## Uputstvo za rešenja

Ukoliko rešite zadatke sa vežbi i želite da ih podelite sa kolegama, napravite Pull Request koji će u sebi sadržati sledeće:

* Python skripte (sve 4 sa ovih vežbi) koja se zovu isto kao i skripte sa vežbi. Na početku skripte u komentaru navesti ko je autor skripte.
* Jasno označiti svaki rešeni zadatak sa komentarom - npr. za rešen 5. zadatak, u samom kodu navesti ```# TODO 5: ... ```
* Skripte staviti u ovaj folder - **solutions**
