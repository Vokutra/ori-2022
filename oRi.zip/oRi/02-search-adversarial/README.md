## Vežba 2 - Pretrage sa suparnikom/protivnikom

Otvoriti datoteku **02-search-adversarial.ipynb**.
