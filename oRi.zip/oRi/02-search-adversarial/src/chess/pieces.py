from abc import *


class Piece(object):
    """
    Apstraktna klasa za sahovske figure.
    """
    def __init__(self, board, row, col, side):
        self.board = board
        self.row = row
        self.col = col
        self.side = side

    @abstractmethod
    def get_legal_moves(self):
        """
        Apstraktna metoda koja treba da za konkretnu figuru vrati moguce sledece poteze (pozicije).
        """
        pass

    def get_value(self):
        """
        Vrednost figure modifikovana u odnosu na igraca.
        Figure crnog (MAX igrac) imaju pozivitnu vrednost, a belog (MIN igrac) negativnu.
        :return: float
        """
        return self.get_value_() if self.side == 'b' else self.get_value_() * -1.

    @abstractmethod
    def get_value_(self):
        """
        Apstraktna metoda koja treba da vrati vrednost za konkretnu figuru.
        """
        pass


class Pawn(Piece):
    """
    Pijun
    """

    def get_legal_moves(self):
        row = self.row
        col = self.col
        side = self.side
        legal_moves = []
        d_rows = []
        d_cols = []

        if side == 'w':  # beli pijun
            # jedan unapred, ako je polje prazno
            if row > 0 and self.board.data[row-1][col] == '.':
                d_rows.append(-1)
                d_cols.append(0)
            # dva unapred, ako je pocetna pozicija i ako je polje prazno
            if row == self.board.rows - 2 and self.board.data[row-1][col] == '.' and self.board.data[row-2][col] == '.':
                d_rows.append(-2)
                d_cols.append(0)
            # ukoso levo, jede crnog
            if col > 0 and row > 0 and self.board.data[row-1][col-1].startswith('b'):
                d_rows.append(-1)
                d_cols.append(-1)
            # ukoso desno, jede crnog
            if col < self.board.cols - 1 and row > 0 and self.board.data[row-1][col+1].startswith('b'):
                d_rows.append(-1)
                d_cols.append(1)
        else:  # crni pijun
            # TODO 2: Implementirati moguce sledece poteze za crnog pijuna
            # jedan unapred, ako je polje prazno
            if row < 7 and self.board.data[row + 1][col] == '.':
                d_rows.append(1)
                d_cols.append(0)
            # dva unapred, ako je pocetna pozicija i ako je polje prazno
            if row == 1 and self.board.data[row + 1][col] == '.' and self.board.data[row + 2][col] == '.':
                d_rows.append(2)
                d_cols.append(0)
            # ukoso levo, jede belog
            if col > 0 and row < 7 and self.board.data[row + 1][col - 1].startswith('w'):
                d_rows.append(1)
                d_cols.append(-1)
            # ukoso desno, jede belog
            if col < self.board.cols - 1 and row < 7 and self.board.data[row + 1][col + 1].startswith('w'):
                d_rows.append(1)
                d_cols.append(1)

        for d_row, d_col in zip(d_rows, d_cols):
            new_row = row + d_row
            new_col = col + d_col
            if 0 <= new_row < self.board.rows and 0 <= new_col < self.board.cols:
                legal_moves.append((new_row, new_col))

        return legal_moves

    def get_value_(self):
        return 1.  # pijun ima vrednost 1


class Knight(Piece):
    """
    Konj
    """
    def get_legal_moves(self):
        row = self.row
        col = self.col
        side = self.side
        legal_moves = []

        d_rows = [-2, -2, -1, -1, 1, 1, 2, 2]
        d_cols = [-1, 1, -2, 2, -2, 2, -1, 1]

        for d_row, d_col in zip(d_rows, d_cols):
            new_row = row + d_row
            new_col = col + d_col
            if side == 'w':
                if 0 <= new_row < self.board.rows and 0 <= new_col < self.board.cols:
                    if self.board.data[new_row][new_col].startswith('b') or self.board.data[new_row][new_col] == '.':
                        legal_moves.append((new_row, new_col))
            else:
                if 0 <= new_row < self.board.rows and 0 <= new_col < self.board.cols:
                    if self.board.data[new_row][new_col].startswith('w') or self.board.data[new_row][new_col] == '.':
                        legal_moves.append((new_row, new_col))
        return legal_moves

    def get_value_(self):
        return 3


class Bishop(Piece):
    """
    Lovac
    """
    def get_legal_moves(self):
        row, col = self.row, self.col  # trenutno pozicija
        side = self.side
        legal_positions = []

        if side == 'w':
            # kretanje dole desno
            break_flag = False
            for d_rows in range(1, self.board.rows, 1):
                for d_cols in range(1, self.board.cols, 1):
                    new_row = row + d_rows  # nova pozicija po redu
                    new_col = col + d_cols  # nova pozicija po koloni
                    if abs(d_rows) == abs(d_cols):
                        if 0 <= new_row < self.board.rows and 0 <= new_col < self.board.cols:
                            if self.board.data[new_row][new_col].startswith('w'):
                                break_flag = True
                                break
                            if self.board.data[new_row][new_col].startswith('b'):
                                legal_positions.append((new_row, new_col))
                                break_flag = True
                                break
                            legal_positions.append((new_row, new_col))
                if break_flag:
                    break

            # kretanje gore levo
            break_flag = False
            for d_rows in range(-1, -self.board.rows, -1):
                for d_cols in range(-1, -self.board.cols, -1):
                    new_row = row + d_rows  # nova pozicija po redu
                    new_col = col + d_cols  # nova pozicija po koloni
                    if abs(d_rows) == abs(d_cols):
                        if 0 <= new_row < self.board.rows and 0 <= new_col < self.board.cols:
                            if self.board.data[new_row][new_col].startswith('w'):
                                break_flag = True
                                break
                            if self.board.data[new_row][new_col].startswith('b'):
                                legal_positions.append((new_row, new_col))
                                break_flag = True
                                break
                            legal_positions.append((new_row, new_col))
                if break_flag:
                    break

            # kretanje dole levo
            break_flag = False
            for d_rows in range(1, self.board.rows, 1):
                for d_cols in range(-1, -self.board.cols, -1):
                    new_row = row + d_rows  # nova pozicija po redu
                    new_col = col + d_cols  # nova pozicija po koloni
                    if abs(d_rows) == abs(d_cols):
                        if 0 <= new_row < self.board.rows and 0 <= new_col < self.board.cols:
                            if self.board.data[new_row][new_col].startswith('w'):
                                break_flag = True
                                break
                            if self.board.data[new_row][new_col].startswith('b'):
                                legal_positions.append((new_row, new_col))
                                break_flag = True
                                break
                            legal_positions.append((new_row, new_col))
                if break_flag:
                    break

            # kretanje gore desno
            break_flag = False
            for d_rows in range(-1, -self.board.rows, -1):
                for d_cols in range(1, self.board.cols, 1):
                    new_row = row + d_rows  # nova pozicija po redu
                    new_col = col + d_cols  # nova pozicija po koloni
                    if abs(d_rows) == abs(d_cols):
                        if 0 <= new_row < self.board.rows and 0 <= new_col < self.board.cols:
                            if self.board.data[new_row][new_col].startswith('w'):
                                break_flag = True
                                break
                            if self.board.data[new_row][new_col].startswith('b'):
                                legal_positions.append((new_row, new_col))
                                break_flag = True
                                break
                            legal_positions.append((new_row, new_col))
                if break_flag:
                    break
        else:
            # kretanje dole desno
            break_flag = False
            for d_rows in range(1, self.board.rows, 1):
                for d_cols in range(1, self.board.cols, 1):
                    new_row = row + d_rows  # nova pozicija po redu
                    new_col = col + d_cols  # nova pozicija po koloni
                    if abs(d_rows) == abs(d_cols):
                        if 0 <= new_row < self.board.rows and 0 <= new_col < self.board.cols:
                            if self.board.data[new_row][new_col].startswith('b'):
                                break_flag = True
                                break
                            if self.board.data[new_row][new_col].startswith('w'):
                                legal_positions.append((new_row, new_col))
                                break_flag = True
                                break
                            legal_positions.append((new_row, new_col))
                if break_flag:
                    break

            # kretanje gore levo
            break_flag = False
            for d_rows in range(-1, -self.board.rows, -1):
                for d_cols in range(-1, -self.board.cols, -1):
                    new_row = row + d_rows  # nova pozicija po redu
                    new_col = col + d_cols  # nova pozicija po koloni
                    if abs(d_rows) == abs(d_cols):
                        if 0 <= new_row < self.board.rows and 0 <= new_col < self.board.cols:
                            if self.board.data[new_row][new_col].startswith('b'):
                                break_flag = True
                                break
                            if self.board.data[new_row][new_col].startswith('w'):
                                legal_positions.append((new_row, new_col))
                                break_flag = True
                                break
                            legal_positions.append((new_row, new_col))
                if break_flag:
                    break

            # kretanje dole levo
            break_flag = False
            for d_rows in range(1, self.board.rows, 1):
                for d_cols in range(-1, -self.board.cols, -1):
                    new_row = row + d_rows  # nova pozicija po redu
                    new_col = col + d_cols  # nova pozicija po koloni
                    if abs(d_rows) == abs(d_cols):
                        if 0 <= new_row < self.board.rows and 0 <= new_col < self.board.cols:
                            if self.board.data[new_row][new_col].startswith('b'):
                                break_flag = True
                                break
                            if self.board.data[new_row][new_col].startswith('w'):
                                legal_positions.append((new_row, new_col))
                                break_flag = True
                                break
                            legal_positions.append((new_row, new_col))
                if break_flag:
                    break

            # kretanje gore desno
            break_flag = False
            for d_rows in range(-1, -self.board.rows, -1):
                for d_cols in range(1, self.board.cols, 1):
                    new_row = row + d_rows  # nova pozicija po redu
                    new_col = col + d_cols  # nova pozicija po koloni
                    if abs(d_rows) == abs(d_cols):
                        if 0 <= new_row < self.board.rows and 0 <= new_col < self.board.cols:
                            if self.board.data[new_row][new_col].startswith('b'):
                                break_flag = True
                                break
                            if self.board.data[new_row][new_col].startswith('w'):
                                legal_positions.append((new_row, new_col))
                                break_flag = True
                                break
                            legal_positions.append((new_row, new_col))
                if break_flag:
                    break

        return legal_positions

    def get_value_(self):
        return 3


class Rook(Piece):
    """
    Top
    """
    def get_legal_moves(self):

        row, col = self.row, self.col  # trenutno pozicija
        side = self.side
        legal_positions = []

        if side == 'w':
            # kretanje na gore
            for d_rows in range(-1, -self.board.rows, -1):
                new_row = row + d_rows  # nova pozicija po redu
                new_col = col  # nova pozicija po koloni
                # ako nova pozicija nije van table i ako nije zid ('w'), ubaci u listu legalnih pozicija
                if 0 <= new_row < self.board.rows and 0 <= new_col < self.board.cols:
                    if self.board.data[new_row][new_col].startswith('w'):
                        break
                    if self.board.data[new_row][new_col].startswith('b'):
                        legal_positions.append((new_row, new_col))
                        break
                    legal_positions.append((new_row, new_col))

            # kretanje na dole
            for d_rows in range(1, self.board.rows, 1):
                new_row = row + d_rows  # nova pozicija po redu
                new_col = col  # nova pozicija po koloni
                # ako nova pozicija nije van table i ako nije zid ('w'), ubaci u listu legalnih pozicija
                if 0 <= new_row < self.board.rows and 0 <= new_col < self.board.cols:
                    if self.board.data[new_row][new_col].startswith('w'):
                        break
                    if self.board.data[new_row][new_col].startswith('b'):
                        legal_positions.append((new_row, new_col))
                        break
                    legal_positions.append((new_row, new_col))
            # kretanje u levo
            for d_cols in range(-1, -self.board.cols, -1):
                new_row = row  # nova pozicija po redu
                new_col = col + d_cols  # nova pozicija po koloni
                # ako nova pozicija nije van table i ako nije zid ('w'), ubaci u listu legalnih pozicija
                if 0 <= new_row < self.board.rows and 0 <= new_col < self.board.cols:
                    if self.board.data[new_row][new_col].startswith('w'):
                        break
                    if self.board.data[new_row][new_col].startswith('b'):
                        legal_positions.append((new_row, new_col))
                        break
                    legal_positions.append((new_row, new_col))

            # kretanje u desno
            for d_cols in range(1, self.board.cols, 1):
                new_row = row  # nova pozicija po redu
                new_col = col + d_cols  # nova pozicija po koloni
                # ako nova pozicija nije van table i ako nije zid ('w'), ubaci u listu legalnih pozicija
                if 0 <= new_row < self.board.rows and 0 <= new_col < self.board.cols:
                    if self.board.data[new_row][new_col].startswith('w'):
                        break
                    if self.board.data[new_row][new_col].startswith('b'):
                        legal_positions.append((new_row, new_col))
                        break
                    legal_positions.append((new_row, new_col))
        else:
            # kretanje na gore
            for d_rows in range(-1, -self.board.rows, -1):
                new_row = row + d_rows  # nova pozicija po redu
                new_col = col  # nova pozicija po koloni
                # ako nova pozicija nije van table i ako nije zid ('w'), ubaci u listu legalnih pozicija
                if 0 <= new_row < self.board.rows and 0 <= new_col < self.board.cols:
                    if self.board.data[new_row][new_col].startswith('b'):
                        break
                    if self.board.data[new_row][new_col].startswith('w'):
                        legal_positions.append((new_row, new_col))
                        break
                    legal_positions.append((new_row, new_col))

            # kretanje na dole
            for d_rows in range(1, self.board.rows, 1):
                new_row = row + d_rows  # nova pozicija po redu
                new_col = col  # nova pozicija po koloni
                # ako nova pozicija nije van table i ako nije zid ('w'), ubaci u listu legalnih pozicija
                if 0 <= new_row < self.board.rows and 0 <= new_col < self.board.cols:
                    if self.board.data[new_row][new_col].startswith('b'):
                        break
                    if self.board.data[new_row][new_col].startswith('w'):
                        legal_positions.append((new_row, new_col))
                        break
                    legal_positions.append((new_row, new_col))
            # kretanje u levo
            for d_cols in range(-1, -self.board.cols, -1):
                new_row = row  # nova pozicija po redu
                new_col = col + d_cols  # nova pozicija po koloni
                # ako nova pozicija nije van table i ako nije zid ('w'), ubaci u listu legalnih pozicija
                if 0 <= new_row < self.board.rows and 0 <= new_col < self.board.cols:
                    if self.board.data[new_row][new_col].startswith('b'):
                        break
                    if self.board.data[new_row][new_col].startswith('w'):
                        legal_positions.append((new_row, new_col))
                        break
                    legal_positions.append((new_row, new_col))

            # kretanje u desno
            for d_cols in range(1, self.board.cols, 1):
                new_row = row  # nova pozicija po redu
                new_col = col + d_cols  # nova pozicija po koloni
                # ako nova pozicija nije van table i ako nije zid ('w'), ubaci u listu legalnih pozicija
                if 0 <= new_row < self.board.rows and 0 <= new_col < self.board.cols:
                    if self.board.data[new_row][new_col].startswith('b'):
                        break
                    if self.board.data[new_row][new_col].startswith('w'):
                        legal_positions.append((new_row, new_col))
                        break
                    legal_positions.append((new_row, new_col))
        return legal_positions

    def get_value_(self):
        return 5


class Queen(Piece):
    """
    Kraljica
    """
    def get_legal_moves(self):
        row, col = self.row, self.col  # trenutno pozicija
        side = self.side
        legal_positions = []

        if side == 'w':

            break_flag = False
            for d_rows in range(1, self.board.rows, 1):
                for d_cols in range(1, self.board.cols, 1):
                    new_row = row + d_rows  # nova pozicija po redu
                    new_col = col + d_cols  # nova pozicija po koloni
                    if abs(d_rows) == abs(d_cols):
                        if 0 <= new_row < self.board.rows and 0 <= new_col < self.board.cols:
                            if self.board.data[new_row][new_col].startswith('w'):
                                break_flag = True
                                break
                            if self.board.data[new_row][new_col].startswith('b'):
                                legal_positions.append((new_row, new_col))
                                break_flag = True
                                break
                            legal_positions.append((new_row, new_col))
                if break_flag:
                    break

            # kretanje gore levo
            break_flag = False
            for d_rows in range(-1, -self.board.rows, -1):
                for d_cols in range(-1, -self.board.cols, -1):
                    new_row = row + d_rows  # nova pozicija po redu
                    new_col = col + d_cols  # nova pozicija po koloni
                    if abs(d_rows) == abs(d_cols):
                        if 0 <= new_row < self.board.rows and 0 <= new_col < self.board.cols:
                            if self.board.data[new_row][new_col].startswith('w'):
                                break_flag = True
                                break
                            if self.board.data[new_row][new_col].startswith('b'):
                                legal_positions.append((new_row, new_col))
                                break_flag = True
                                break
                            legal_positions.append((new_row, new_col))
                if break_flag:
                    break

            # kretanje dole levo
            break_flag = False
            for d_rows in range(1, self.board.rows, 1):
                for d_cols in range(-1, -self.board.cols, -1):
                    new_row = row + d_rows  # nova pozicija po redu
                    new_col = col + d_cols  # nova pozicija po koloni
                    if abs(d_rows) == abs(d_cols):
                        if 0 <= new_row < self.board.rows and 0 <= new_col < self.board.cols:
                            if self.board.data[new_row][new_col].startswith('w'):
                                break_flag = True
                                break
                            if self.board.data[new_row][new_col].startswith('b'):
                                legal_positions.append((new_row, new_col))
                                break_flag = True
                                break
                            legal_positions.append((new_row, new_col))
                if break_flag:
                    break

            # kretanje gore desno
            break_flag = False
            for d_rows in range(-1, -self.board.rows, -1):
                for d_cols in range(1, self.board.cols, 1):
                    new_row = row + d_rows  # nova pozicija po redu
                    new_col = col + d_cols  # nova pozicija po koloni
                    if abs(d_rows) == abs(d_cols):
                        if 0 <= new_row < self.board.rows and 0 <= new_col < self.board.cols:
                            if self.board.data[new_row][new_col].startswith('w'):
                                break_flag = True
                                break
                            if self.board.data[new_row][new_col].startswith('b'):
                                legal_positions.append((new_row, new_col))
                                break_flag = True
                                break
                            legal_positions.append((new_row, new_col))
                if break_flag:
                    break

            # kretanje na gore
            for d_rows in range(-1, -self.board.rows, -1):
                new_row = row + d_rows  # nova pozicija po redu
                new_col = col  # nova pozicija po koloni
                # ako nova pozicija nije van table i ako nije zid ('w'), ubaci u listu legalnih pozicija
                if 0 <= new_row < self.board.rows and 0 <= new_col < self.board.cols:
                    if self.board.data[new_row][new_col].startswith('w'):
                        break
                    if self.board.data[new_row][new_col].startswith('b'):
                        legal_positions.append((new_row, new_col))
                        break
                    legal_positions.append((new_row, new_col))

            # kretanje na dole
            for d_rows in range(1, self.board.rows, 1):
                new_row = row + d_rows  # nova pozicija po redu
                new_col = col  # nova pozicija po koloni
                # ako nova pozicija nije van table i ako nije zid ('w'), ubaci u listu legalnih pozicija
                if 0 <= new_row < self.board.rows and 0 <= new_col < self.board.cols:
                    if self.board.data[new_row][new_col].startswith('w'):
                        break
                    if self.board.data[new_row][new_col].startswith('b'):
                        legal_positions.append((new_row, new_col))
                        break
                    legal_positions.append((new_row, new_col))
            # kretanje u levo
            for d_cols in range(-1, -self.board.cols, -1):
                new_row = row  # nova pozicija po redu
                new_col = col + d_cols  # nova pozicija po koloni
                # ako nova pozicija nije van table i ako nije zid ('w'), ubaci u listu legalnih pozicija
                if 0 <= new_row < self.board.rows and 0 <= new_col < self.board.cols:
                    if self.board.data[new_row][new_col].startswith('w'):
                        break
                    if self.board.data[new_row][new_col].startswith('b'):
                        legal_positions.append((new_row, new_col))
                        break
                    legal_positions.append((new_row, new_col))

            # kretanje u desno
            for d_cols in range(1, self.board.cols, 1):
                new_row = row  # nova pozicija po redu
                new_col = col + d_cols  # nova pozicija po koloni
                # ako nova pozicija nije van table i ako nije zid ('w'), ubaci u listu legalnih pozicija
                if 0 <= new_row < self.board.rows and 0 <= new_col < self.board.cols:
                    if self.board.data[new_row][new_col].startswith('w'):
                        break
                    if self.board.data[new_row][new_col].startswith('b'):
                        legal_positions.append((new_row, new_col))
                        break
                    legal_positions.append((new_row, new_col))
        else:

            # kretanje dole desno
            break_flag = False
            for d_rows in range(1, self.board.rows, 1):
                for d_cols in range(1, self.board.cols, 1):
                    new_row = row + d_rows  # nova pozicija po redu
                    new_col = col + d_cols  # nova pozicija po koloni
                    if abs(d_rows) == abs(d_cols):
                        if 0 <= new_row < self.board.rows and 0 <= new_col < self.board.cols:
                            if self.board.data[new_row][new_col].startswith('b'):
                                break_flag = True
                                break
                            if self.board.data[new_row][new_col].startswith('w'):
                                legal_positions.append((new_row, new_col))
                                break_flag = True
                                break
                            legal_positions.append((new_row, new_col))
                if break_flag:
                    break

            # kretanje gore levo
            break_flag = False
            for d_rows in range(-1, -self.board.rows, -1):
                for d_cols in range(-1, -self.board.cols, -1):
                    new_row = row + d_rows  # nova pozicija po redu
                    new_col = col + d_cols  # nova pozicija po koloni
                    if abs(d_rows) == abs(d_cols):
                        if 0 <= new_row < self.board.rows and 0 <= new_col < self.board.cols:
                            if self.board.data[new_row][new_col].startswith('b'):
                                break_flag = True
                                break
                            if self.board.data[new_row][new_col].startswith('w'):
                                legal_positions.append((new_row, new_col))
                                break_flag = True
                                break
                            legal_positions.append((new_row, new_col))
                if break_flag:
                    break

            # kretanje dole levo
            break_flag = False
            for d_rows in range(1, self.board.rows, 1):
                for d_cols in range(-1, -self.board.cols, -1):
                    new_row = row + d_rows  # nova pozicija po redu
                    new_col = col + d_cols  # nova pozicija po koloni
                    if abs(d_rows) == abs(d_cols):
                        if 0 <= new_row < self.board.rows and 0 <= new_col < self.board.cols:
                            if self.board.data[new_row][new_col].startswith('b'):
                                break_flag = True
                                break
                            if self.board.data[new_row][new_col].startswith('w'):
                                legal_positions.append((new_row, new_col))
                                break_flag = True
                                break
                            legal_positions.append((new_row, new_col))
                if break_flag:
                    break

            # kretanje gore desno
            break_flag = False
            for d_rows in range(-1, -self.board.rows, -1):
                for d_cols in range(1, self.board.cols, 1):
                    new_row = row + d_rows  # nova pozicija po redu
                    new_col = col + d_cols  # nova pozicija po koloni
                    if abs(d_rows) == abs(d_cols):
                        if 0 <= new_row < self.board.rows and 0 <= new_col < self.board.cols:
                            if self.board.data[new_row][new_col].startswith('b'):
                                break_flag = True
                                break
                            if self.board.data[new_row][new_col].startswith('w'):
                                legal_positions.append((new_row, new_col))
                                break_flag = True
                                break
                            legal_positions.append((new_row, new_col))
                if break_flag:
                    break

            # kretanje na gore
            for d_rows in range(-1, -self.board.rows, -1):
                new_row = row + d_rows  # nova pozicija po redu
                new_col = col  # nova pozicija po koloni
                # ako nova pozicija nije van table i ako nije zid ('w'), ubaci u listu legalnih pozicija
                if 0 <= new_row < self.board.rows and 0 <= new_col < self.board.cols:
                    if self.board.data[new_row][new_col].startswith('b'):
                        break
                    if self.board.data[new_row][new_col].startswith('w'):
                        legal_positions.append((new_row, new_col))
                        break
                    legal_positions.append((new_row, new_col))

            # kretanje na dole
            for d_rows in range(1, self.board.rows, 1):
                new_row = row + d_rows  # nova pozicija po redu
                new_col = col  # nova pozicija po koloni
                # ako nova pozicija nije van table i ako nije zid ('w'), ubaci u listu legalnih pozicija
                if 0 <= new_row < self.board.rows and 0 <= new_col < self.board.cols:
                    if self.board.data[new_row][new_col].startswith('b'):
                        break
                    if self.board.data[new_row][new_col].startswith('w'):
                        legal_positions.append((new_row, new_col))
                        break
                    legal_positions.append((new_row, new_col))
            # kretanje u levo
            for d_cols in range(-1, -self.board.cols, -1):
                new_row = row  # nova pozicija po redu
                new_col = col + d_cols  # nova pozicija po koloni
                # ako nova pozicija nije van table i ako nije zid ('w'), ubaci u listu legalnih pozicija
                if 0 <= new_row < self.board.rows and 0 <= new_col < self.board.cols:
                    if self.board.data[new_row][new_col].startswith('b'):
                        break
                    if self.board.data[new_row][new_col].startswith('w'):
                        legal_positions.append((new_row, new_col))
                        break
                    legal_positions.append((new_row, new_col))

            # kretanje u desno
            for d_cols in range(1, self.board.cols, 1):
                new_row = row  # nova pozicija po redu
                new_col = col + d_cols  # nova pozicija po koloni
                # ako nova pozicija nije van table i ako nije zid ('w'), ubaci u listu legalnih pozicija
                if 0 <= new_row < self.board.rows and 0 <= new_col < self.board.cols:
                    if self.board.data[new_row][new_col].startswith('b'):
                        break
                    if self.board.data[new_row][new_col].startswith('w'):
                        legal_positions.append((new_row, new_col))
                        break
                    legal_positions.append((new_row, new_col))
        return legal_positions

    def get_value_(self):
        return 9


class King(Piece):
    """
    Kralj
    """
    def get_legal_moves(self):
        row = self.row
        col = self.col
        side = self.side
        legal_moves = []
        d_rows = []
        d_cols = []

        if side == 'w':  # beli kralj
            # jedan gore, ako je polje prazno ili crna figura
            if row > 0 and (self.board.data[row - 1][col] == '.' or self.board.data[row-1][col].startswith('b')):
                d_rows.append(-1)
                d_cols.append(0)
            # jedan dole, ako je polje prazno ili crna figura
            if row < self.board.rows - 1 and (self.board.data[row + 1][col] == '.' or self.board.data[row + 1][col].startswith('b')):
                d_rows.append(1)
                d_cols.append(0)
            # jedan levo, ako je polje prazno ili crna figura
            if col > 0 and (self.board.data[row][col - 1] == '.' or self.board.data[row][col - 1].startswith('b')):
                d_rows.append(0)
                d_cols.append(-1)
            # jedan desno, ako je polje prazno ili crna figura
            if col < self.board.cols - 1 and (self.board.data[row][col + 1] == '.' or self.board.data[row][col + 1].startswith('b')):
                d_rows.append(0)
                d_cols.append(1)
            # jedan gore levo, ako je polje prazno ili crna figura
            if row > 0 and col > 0 and (self.board.data[row - 1][col - 1] == '.' or self.board.data[row - 1][col - 1].startswith('b')):
                d_rows.append(-1)
                d_cols.append(-1)
            # jedan gore desno, ako je polje prazno ili crna figura
            if row > 0 and col < self.board.cols - 1 and (self.board.data[row - 1][col + 1] == '.' or self.board.data[row - 1][col + 1].startswith('b')):
                d_rows.append(-1)
                d_cols.append(1)
            # jedan dole levo, ako je polje prazno ili crna figura
            if row < self.board.rows - 1 and col > 0 and (self.board.data[row + 1][col - 1] == '.' or self.board.data[row + 1][col - 1].startswith('b')):
                d_rows.append(1)
                d_cols.append(-1)
            # jedan dole desno, ako je polje prazno ili crna figura
            if row < self.board.rows - 1 and col < self.board.cols - 1 and (self.board.data[row + 1][col + 1] == '.' or self.board.data[row + 1][col + 1].startswith('b')):
                d_rows.append(1)
                d_cols.append(1)
        else: #crni kralj
            # jedan gore, ako je polje prazno ili crna figura
            if row > 0 and (self.board.data[row - 1][col] == '.' or self.board.data[row - 1][col].startswith('w')):
                d_rows.append(-1)
                d_cols.append(0)
            # jedan dole, ako je polje prazno ili crna figura
            if row < self.board.rows - 1 and (
                    self.board.data[row + 1][col] == '.' or self.board.data[row + 1][col].startswith('w')):
                d_rows.append(1)
                d_cols.append(0)
            # jedan levo, ako je polje prazno ili crna figura
            if col > 0 and (self.board.data[row][col - 1] == '.' or self.board.data[row][col - 1].startswith('w')):
                d_rows.append(0)
                d_cols.append(-1)
            # jedan desno, ako je polje prazno ili crna figura
            if col < self.board.cols - 1 and (
                    self.board.data[row][col + 1] == '.' or self.board.data[row][col + 1].startswith('w')):
                d_rows.append(0)
                d_cols.append(1)
            # jedan gore levo, ako je polje prazno ili crna figura
            if row > 0 and col > 0 and (
                    self.board.data[row - 1][col - 1] == '.' or self.board.data[row - 1][col - 1].startswith('w')):
                d_rows.append(-1)
                d_cols.append(-1)
            # jedan gore desno, ako je polje prazno ili crna figura
            if row > 0 and col < self.board.cols - 1 and (
                    self.board.data[row - 1][col + 1] == '.' or self.board.data[row - 1][col + 1].startswith('w')):
                d_rows.append(-1)
                d_cols.append(1)
            # jedan dole levo, ako je polje prazno ili crna figura
            if row < self.board.rows - 1 and col > 0 and (
                    self.board.data[row + 1][col - 1] == '.' or self.board.data[row + 1][col - 1].startswith('w')):
                d_rows.append(1)
                d_cols.append(-1)
            # jedan dole desno, ako je polje prazno ili crna figura
            if row < self.board.rows - 1 and col < self.board.cols - 1 and (
                    self.board.data[row + 1][col + 1] == '.' or self.board.data[row + 1][col + 1].startswith('w')):
                d_rows.append(1)
                d_cols.append(1)

        for d_row, d_col in zip(d_rows, d_cols):
            new_row = row + d_row
            new_col = col + d_col
            if 0 <= new_row < self.board.rows and 0 <= new_col < self.board.cols:
                legal_moves.append((new_row, new_col))

        return legal_moves

    def get_value_(self):
        return 10000000000000
