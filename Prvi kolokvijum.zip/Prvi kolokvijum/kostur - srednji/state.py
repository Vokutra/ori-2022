from abc import *
from collections import deque
from copy import deepcopy


class State(object):
    """
    Apstraktna klasa koja opisuje stanje pretrage.
    """

    @abstractmethod
    def __init__(self, board, parent=None, position=None, goal_position=None, movement_type = None):
        """
        :param board: Board (tabla)
        :param parent: roditeljsko stanje
        :param position: pozicija stanja
        :param goal_position: pozicija krajnjeg stanja
        :return:
        """
        self.board = board
        self.parent = parent  # roditeljsko stanje
        if self.parent is None:  # ako nema roditeljsko stanje, onda je ovo inicijalno stanje
            self.position = board.find_position(self.get_agent_code())  # pronadji pocetnu poziciju
            self.goal_position = board.find_position(self.get_agent_goal_code())  # pronadji krajnju poziciju
        else:  # ako ima roditeljsko stanje, samo sacuvaj vrednosti parametara
            self.position = position
            self.goal_position = goal_position
        self.depth = parent.depth + 1 if parent is not None else 1  # povecaj dubinu/nivo pretrage

    def get_next_states(self):
        new_positions = self.get_legal_positions()  # dobavi moguce (legalne) sledece pozicije iz trenutne pozicije
        next_states = []
        # napravi listu mogucih sledecih stanja na osnovu mogucih sledecih pozicija
        for new_position in new_positions:
            next_state = self.__class__(self.board, self, new_position, self.goal_position)
            next_states.append(next_state)
        return next_states

    @abstractmethod
    def get_agent_code(self):
        """
        Apstraktna metoda koja treba da vrati kod agenta na tabli.
        :return: str
        """
        pass

    @abstractmethod
    def get_agent_goal_code(self):
        """
        Apstraktna metoda koja treba da vrati kod agentovog cilja na tabli.
        :return: str
        """
        pass

    @abstractmethod
    def get_legal_positions(self):
        """
        Apstraktna metoda koja treba da vrati moguce (legalne) sledece pozicije na osnovu trenutne pozicije.
        :return: list
        """
        pass

    @abstractmethod
    def is_final_state(self):
        """
        Apstraktna metoda koja treba da vrati da li je treuntno stanje zapravo zavrsno stanje.
        :return: bool
        """
        pass

    @abstractmethod
    def unique_hash(self):
        """
        Apstraktna metoda koja treba da vrati string koji je JEDINSTVEN za ovo stanje
        (u odnosu na ostala stanja).
        :return: str
        """
        pass
    
    @abstractmethod
    def get_cost(self):
        """
        Apstraktna metoda koja treba da vrati procenu cene
        (vrednost heuristicke funkcije) za ovo stanje.
        Koristi se za vodjene pretrage.
        :return: float
        """
        pass
    
    @abstractmethod
    def get_current_cost(self):
        """
        Apstraktna metoda koja treba da vrati stvarnu trenutnu cenu za ovo stanje.
        Koristi se za vodjene pretrage.
        :return: float
        """
        pass


class RobotState(State):
    def __init__(self, board, parent=None, position=None, goal_position=None, movement_type = 'Kralj'):
        super(self.__class__, self).__init__(board, parent, position, goal_position, movement_type)
        # posle pozivanja super konstruktora, mogu se dodavati "custom" stvari vezani za stanje
        # TODO 6: prosiriti stanje sa informacijom da li je robot pokupio kutiju (sve kutije na tabli)
        # self.movement = movement_type
        self.collected_cakes = deque([]) #plavo
        self.collected_person = deque([]) #zeleno
        self.cake_number = 0
        self.person_number = 0
        self.dostavio = False

        if parent is not None:
            self.collected_cakes = deepcopy(parent.collected_cakes)
            self.collected_person = deepcopy(parent.collected_person)
            self.cake_number = parent.cake_number
            self.person_number = parent.person_number

            self.cakes, self.cakes_counter = parent.cakes, parent.cakes_counter
            self.persons, self.person_counter = parent.persons, parent.person_counter
        else:
            self.cakes, self.cakes_counter = board.find_positions('b')
            self.persons, self.person_counter = board.find_positions('o')

        for cake in self.cakes:
            if cake not in self.collected_cakes and cake == self.position:
                self.collected_cakes.append(cake)
                self.cake_number += 1

        for person in self.persons:
            if person not in self.collected_person and person == self.persons:
                self.collected_person.append(person)
                self.person_number += 1




    def get_agent_code(self):
        return 'r'

    def get_agent_goal_code(self):
        return 'g'

    def get_legal_positions(self):
        # d_rows (delta rows), d_cols (delta columns)

        # if self.movement == 'Kralj':
        # moguci smerovi kretanja robota (desno, levo, dole, gore)
        #TODO 5: Omoguciti kretanje robota i po dijagonalama

        row, col = self.position  # trenutno pozicija
        new_positions = []

        if self.cake_number == 0:
            for d_rows in range(0, -self.board.rows, -1):
                new_row = row + d_rows  # nova pozicija po redu
                new_col = col  # nova pozicija po koloni
                # ako nova pozicija nije van table i ako nije zid ('w'), ubaci u listu legalnih pozicija
                if 0 <= new_row < self.board.rows and 0 <= new_col < self.board.cols and self.board.data[new_row][
                    new_col] != 'w':
                    new_positions.append((new_row, new_col))
                if 0 <= new_row < self.board.rows and 0 <= new_col < self.board.cols and self.board.data[new_row][
                    new_col] == 'w':
                    break
            for d_rows in range(0, self.board.rows, 1):
                new_row = row + d_rows  # nova pozicija po redu
                new_col = col  # nova pozicija po koloni
                # ako nova pozicija nije van table i ako nije zid ('w'), ubaci u listu legalnih pozicija
                if 0 <= new_row < self.board.rows and 0 <= new_col < self.board.cols and self.board.data[new_row][
                    new_col] != 'w':
                    new_positions.append((new_row, new_col))
                if 0 <= new_row < self.board.rows and 0 <= new_col < self.board.cols and self.board.data[new_row][
                    new_col] == 'w':
                    break

            for d_cols in range(0, -self.board.cols, -1):
                new_row = row  # nova pozicija po redu
                new_col = col + d_cols  # nova pozicija po koloni
                # ako nova pozicija nije van table i ako nije zid ('w'), ubaci u listu legalnih pozicija
                if 0 <= new_row < self.board.rows and 0 <= new_col < self.board.cols and self.board.data[new_row][
                    new_col] != 'w':
                    new_positions.append((new_row, new_col))
                if 0 <= new_row < self.board.rows and 0 <= new_col < self.board.cols and self.board.data[new_row][
                    new_col] == 'w':
                    break

            for d_cols in range(0, self.board.cols, 1):
                new_row = row  # nova pozicija po redu
                new_col = col + d_cols  # nova pozicija po koloni
                # ako nova pozicija nije van table i ako nije zid ('w'), ubaci u listu legalnih pozicija
                if 0 <= new_row < self.board.rows and 0 <= new_col < self.board.cols and self.board.data[new_row][
                    new_col] != 'w':
                    new_positions.append((new_row, new_col))
                if 0 <= new_row < self.board.rows and 0 <= new_col < self.board.cols and self.board.data[new_row][
                    new_col] == 'w':
                    break

        else:
            d_rows = [0, 0, 1, -1]
            d_cols = [1, -1, 0, 0]


            for d_row, d_col in zip(d_rows, d_cols):  # za sve moguce smerove
                 new_row = row + d_row  # nova pozicija po redu
                 new_col = col + d_col  # nova pozicija po koloni
                 # ako nova pozicija nije van table i ako nije zid ('w'), ubaci u listu legalnih pozicija
                 if 0 <= new_row < self.board.rows and 0 <= new_col < self.board.cols and self.board.data[new_row][new_col] != 'w':
                    new_positions.append((new_row, new_col))
        """
        #TODO: Omoguciti kretanje ostalih figura *DODATNI*
        elif self.movement == 'Top':
        elif self.movement == 'Kraljica':
        elif self.movement == 'Konj':
        """
        # # TODO 7: Portali
        # portal_positions, br_portala = self.board.find_positions('p')
        # if self.position in portal_positions:
        #     # U legalne pozicije dodati sve ostele portale sem tog na kom se trenutno nalazimo
        #     portal_positions.remove(self.position)
        #     new_positions.extend(portal_positions)

        return new_positions

    def is_final_state(self):
        #Dodata informacija i da mora da ima sve kutije da bi bio kraj
        return self.position == self.goal_position and self.cake_number == len(self.cakes)

    def unique_hash(self):
        hash_code = self.position
        if len(self.collected_cakes) > 0:
            for cake in self.collected_cakes:
                hash_code = hash_code, cake
        if len(self.collected_person) > 0:
            for person in self.collected_person:
                hash_code = hash_code, person

        return str(hash_code)

    def get_cost(self):
        x1 = self.position[0]
        y1 = self.position[1]

        x2 = self.goal_position[0]
        y2 = self.goal_position[1]

        distance = ((x1 - x2) ** 2 + (y1 - y2) ** 2) ** 0.5

        return distance

    def get_current_cost(self):
        return self.depth
