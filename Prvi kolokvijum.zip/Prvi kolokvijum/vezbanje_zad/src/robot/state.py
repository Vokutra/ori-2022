from abc import *
from collections import deque
from copy import deepcopy
import random

class State(object):
    """
    Apstraktna klasa koja opisuje stanje pretrage.
    """

    @abstractmethod
    def __init__(self, board, parent=None, position=None, goal_position=None):
        """
        :param board: Board (tabla)
        :param parent: roditeljsko stanje
        :param position: pozicija stanja
        :param goal_position: pozicija krajnjeg stanja
        :return:
        """
        self.board = board
        self.parent = parent  # roditeljsko stanje
        if self.parent is None:  # ako nema roditeljsko stanje, onda je ovo inicijalno stanje
            self.position = board.find_position(self.get_agent_code())  # pronadji pocetnu poziciju
            self.goal_position = board.find_position(self.get_agent_goal_code())  # pronadji krajnju poziciju
        else:  # ako ima roditeljsko stanje, samo sacuvaj vrednosti parametara
            self.position = position
            self.goal_position = goal_position
        self.depth = parent.depth + 1 if parent is not None else 1  # povecaj dubinu/nivo pretrage

    def get_next_states(self):
        new_positions = self.get_legal_positions()  # dobavi moguce (legalne) sledece pozicije iz trenutne pozicije
        next_states = []
        # napravi listu mogucih sledecih stanja na osnovu mogucih sledecih pozicija
        for new_position in new_positions:
            next_state = self.__class__(self.board, self, new_position, self.goal_position)
            next_states.append(next_state)
        return next_states

    @abstractmethod
    def get_agent_code(self):
        """
        Apstraktna metoda koja treba da vrati kod agenta na tabli.
        :return: str
        """
        pass

    @abstractmethod
    def get_agent_goal_code(self):
        """
        Apstraktna metoda koja treba da vrati kod agentovog cilja na tabli.
        :return: str
        """
        pass

    @abstractmethod
    def get_legal_positions(self):
        """
        Apstraktna metoda koja treba da vrati moguce (legalne) sledece pozicije na osnovu trenutne pozicije.
        :return: list
        """
        pass

    @abstractmethod
    def is_final_state(self):
        """
        Apstraktna metoda koja treba da vrati da li je treuntno stanje zapravo zavrsno stanje.
        :return: bool
        """
        pass

    @abstractmethod
    def unique_hash(self):
        """
        Apstraktna metoda koja treba da vrati string koji je JEDINSTVEN za ovo stanje
        (u odnosu na ostala stanja).
        :return: str
        """
        pass

    @abstractmethod
    def get_cost(self):
        """
        Apstraktna metoda koja treba da vrati procenu cene
        (vrednost heuristicke funkcije) za ovo stanje.
        Koristi se za vodjene pretrage.
        :return: float
        """
        pass

    @abstractmethod
    def get_current_cost(self):
        """
        Apstraktna metoda koja treba da vrati stvarnu trenutnu cenu za ovo stanje.
        Koristi se za vodjene pretrage.
        :return: float
        """
        pass


class TeniserState(State):
    def __init__(self, board, parent=None, position=None, goal_position=None):
        super(self.__class__, self).__init__(board, parent, position, goal_position)
        # posle pozivanja super konstruktora, mogu se dodavati "custom" stvari vezani za stanje
        # Pokupi tri plave, dve zelene i izbegavaj ljubicaste, kad ih pokupise tezi blize ljubicastim i idi na cilj
        # dok ne pokupis plave kreci se kao top, a posle kao lovac (lovac i konj jos napraviti)
        self.end_game = False
        self.have_blue_boxes = False
        self.have_green_boxes = False
        self.collected_blue_boxes = deque([])
        self.collected_green_boxes = deque([])
        self.blue_count = 0

        if parent is not None:
            self.end_game = parent.end_game
            self.have_blue_boxes = parent.have_blue_boxes
            self.have_green_boxes = parent.have_green_boxes
            self.collected_blue_boxes = deepcopy(parent.collected_blue_boxes)
            self.collected_green_boxes = deepcopy(parent.collected_green_boxes)
            self.blue_count = parent.blue_count

            self.blue_boxes, self. blue_boxes_count = parent.blue_boxes, parent.blue_boxes_count
            self.green_boxes, self.green_boxes_count = parent.green_boxes, parent.green_boxes_count
            self.fires, self.fires_count = parent.fires, parent.fires_count

        else:
            self.blue_boxes, self.blue_boxes_count = self.board.find_positions('b')
            self.green_boxes, self.green_boxes_count = self.board.find_positions('z')
            self.fires, self.fires_count = self.board.find_positions('f')


        for blue in self.blue_boxes:
            if blue == self.position and blue not in self.collected_blue_boxes:
                self.collected_blue_boxes.append(blue)
                self.blue_count +=1

        for green in self.green_boxes:
            if green == self.position and green not in self.collected_green_boxes:
                self.collected_green_boxes.append(green)


        if len(self.collected_blue_boxes) == 3:
            self.have_blue_boxes = True

        if len(self.collected_green_boxes) == 2:
            self.have_green_boxes = True

        if self.have_blue_boxes and self.have_green_boxes:
            self.end_game = True


    def get_agent_code(self):
        return 'r'

    def get_agent_goal_code(self):
        return 'g'

    def get_legal_positions(self):
        # d_rows (delta rows), d_cols (delta columns)
        # moguci smerovi kretanja robota (desno, levo, dole, gore)

        row, col = self.position  # trenutno pozicija
        new_positions = []

        if self.blue_count >= 3:
            deltas = [(-1, 1), (-1, -1), (1, -1), (1, 1), (-1, 0), (0, -1), (1, 0), (0, 1)]
            for d in deltas:
                for i in range(1, 20):
                    new_row = row + d[0] * i
                    new_col = col + d[1] * i
                    if 0 <= new_row < self.board.rows and 0 <= new_col < self.board.cols and self.board.data[new_row][new_col] != 'w':
                        new_positions.append((new_row, new_col))
        else:
            #TOP
            for d_rows in range(0, -self.board.rows, -1):
                new_row = row + d_rows  # nova pozicija po redu
                new_col = col  # nova pozicija po koloni
                # ako nova pozicija nije van table i ako nije zid ('w'), ubaci u listu legalnih pozicija
                if 0 <= new_row < self.board.rows and 0 <= new_col < self.board.cols and self.board.data[new_row][
                    new_col] != 'w':
                    new_positions.append((new_row, new_col))
                if 0 <= new_row < self.board.rows and 0 <= new_col < self.board.cols and self.board.data[new_row][
                    new_col] == 'w':
                    break
            for d_rows in range(0, self.board.rows, 1):
                new_row = row + d_rows  # nova pozicija po redu
                new_col = col  # nova pozicija po koloni
                # ako nova pozicija nije van table i ako nije zid ('w'), ubaci u listu legalnih pozicija
                if 0 <= new_row < self.board.rows and 0 <= new_col < self.board.cols and self.board.data[new_row][
                    new_col] != 'w':
                    new_positions.append((new_row, new_col))
                if 0 <= new_row < self.board.rows and 0 <= new_col < self.board.cols and self.board.data[new_row][
                    new_col] == 'w':
                    break

            for d_cols in range(0, -self.board.cols, -1):
                new_row = row  # nova pozicija po redu
                new_col = col + d_cols  # nova pozicija po koloni
                # ako nova pozicija nije van table i ako nije zid ('w'), ubaci u listu legalnih pozicija
                if 0 <= new_row < self.board.rows and 0 <= new_col < self.board.cols and self.board.data[new_row][
                    new_col] != 'w':
                    new_positions.append((new_row, new_col))
                if 0 <= new_row < self.board.rows and 0 <= new_col < self.board.cols and self.board.data[new_row][
                    new_col] == 'w':
                    break

            for d_cols in range(0, self.board.cols, 1):
                new_row = row  # nova pozicija po redu
                new_col = col + d_cols  # nova pozicija po koloni
                # ako nova pozicija nije van table i ako nije zid ('w'), ubaci u listu legalnih pozicija
                if 0 <= new_row < self.board.rows and 0 <= new_col < self.board.cols and self.board.data[new_row][
                    new_col] != 'w':
                    new_positions.append((new_row, new_col))
                if 0 <= new_row < self.board.rows and 0 <= new_col < self.board.cols and self.board.data[new_row][
                    new_col] == 'w':
                    break






        # d_rows = [0, 0, 1, -1]
        # d_cols = [1, -1, 0, 0]
        # row, col = self.position  # trenutno pozicija
        # new_positions = []
        # for d_row, d_col in zip(d_rows, d_cols):  # za sve moguce smerove
        #     new_row = row + d_row  # nova pozicija po redu
        #     new_col = col + d_col  # nova pozicija po koloni
        #     # ako nova pozicija nije van table i ako nije zid ('w'), ubaci u listu legalnih pozicija
        #     if 0 <= new_row < self.board.rows and 0 <= new_col < self.board.cols and self.board.data[new_row][
        #         new_col] != 'w':
        #         new_positions.append((new_row, new_col))

        # #KRETANJE KRALJICE
        # row, col = self.position  # trenutno pozicija
        # new_positions = []
        #
        # for d_rows in range(0, -self.board.rows, -1):
        #     new_row = row + d_rows  # nova pozicija po redu
        #     new_col = col  # nova pozicija po koloni
        #     # ako nova pozicija nije van table i ako nije zid ('w'), ubaci u listu legalnih pozicija
        #     if 0 <= new_row < self.board.rows and 0 <= new_col < self.board.cols and self.board.data[new_row][
        #         new_col] != 'w':
        #         new_positions.append((new_row, new_col))
        #     if 0 <= new_row < self.board.rows and 0 <= new_col < self.board.cols and self.board.data[new_row][
        #         new_col] == 'w':
        #         break
        # for d_rows in range(0, self.board.rows, 1):
        #     new_row = row + d_rows  # nova pozicija po redu
        #     new_col = col  # nova pozicija po koloni
        #     # ako nova pozicija nije van table i ako nije zid ('w'), ubaci u listu legalnih pozicija
        #     if 0 <= new_row < self.board.rows and 0 <= new_col < self.board.cols and self.board.data[new_row][
        #         new_col] != 'w':
        #         new_positions.append((new_row, new_col))
        #     if 0 <= new_row < self.board.rows and 0 <= new_col < self.board.cols and self.board.data[new_row][
        #         new_col] == 'w':
        #         break
        #
        # for d_cols in range(0, -self.board.cols, -1):
        #     new_row = row  # nova pozicija po redu
        #     new_col = col + d_cols  # nova pozicija po koloni
        #     # ako nova pozicija nije van table i ako nije zid ('w'), ubaci u listu legalnih pozicija
        #     if 0 <= new_row < self.board.rows and 0 <= new_col < self.board.cols and self.board.data[new_row][
        #         new_col] != 'w':
        #         new_positions.append((new_row, new_col))
        #     if 0 <= new_row < self.board.rows and 0 <= new_col < self.board.cols and self.board.data[new_row][
        #         new_col] == 'w':
        #         break
        # for d_cols in range(0, self.board.cols, 1):
        #     new_row = row  # nova pozicija po redu
        #     new_col = col + d_cols  # nova pozicija po koloni
        #     # ako nova pozicija nije van table i ako nije zid ('w'), ubaci u listu legalnih pozicija
        #     if 0 <= new_row < self.board.rows and 0 <= new_col < self.board.cols and self.board.data[new_row][
        #         new_col] != 'w':
        #         new_positions.append((new_row, new_col))
        #     if 0 <= new_row < self.board.rows and 0 <= new_col < self.board.cols and self.board.data[new_row][
        #         new_col] == 'w':
        #         break
        #
        # # dijagonale
        # for d_rows in range(0, self.board.rows, 1):
        #     for d_cols in range(0, self.board.cols, 1):
        #         new_row = row + d_rows  # nova pozicija po redu
        #         new_col = col + d_cols  # nova pozicija po koloni
        #         if abs(d_rows) == abs(d_cols):
        #             if 0 <= new_row < self.board.rows and 0 <= new_col < self.board.cols and \
        #                     self.board.data[new_row][
        #                         new_col] != 'w':
        #                 new_positions.append((new_row, new_col))
        #             if 0 <= new_row < self.board.rows and 0 <= new_col < self.board.cols and \
        #                     self.board.data[new_row][
        #                         new_col] == 'w':
        #                 break
        #     if 0 <= new_row < self.board.rows and 0 <= new_col < self.board.cols and \
        #             self.board.data[new_row][
        #                 new_col] == 'w':
        #         break
        #
        # for d_rows in range(0, -self.board.rows, -1):
        #     for d_cols in range(0, -self.board.cols, -1):
        #         new_row = row + d_rows  # nova pozicija po redu
        #         new_col = col + d_cols  # nova pozicija po koloni
        #         if abs(d_rows) == abs(d_cols):
        #             if 0 <= new_row < self.board.rows and 0 <= new_col < self.board.cols and \
        #                     self.board.data[new_row][
        #                         new_col] != 'w':
        #                 new_positions.append((new_row, new_col))
        #             if 0 <= new_row < self.board.rows and 0 <= new_col < self.board.cols and \
        #                     self.board.data[new_row][
        #                         new_col] == 'w':
        #                 break
        #     if 0 <= new_row < self.board.rows and 0 <= new_col < self.board.cols and \
        #             self.board.data[new_row][
        #                 new_col] == 'w':
        #         break
        #
        # for d_rows in range(0, self.board.rows, 1):
        #     for d_cols in range(0, -self.board.cols, -1):
        #         new_row = row + d_rows  # nova pozicija po redu
        #         new_col = col + d_cols  # nova pozicija po koloni
        #         if abs(d_rows) == abs(d_cols):
        #             if 0 <= new_row < self.board.rows and 0 <= new_col < self.board.cols and \
        #                     self.board.data[new_row][
        #                         new_col] != 'w':
        #                 new_positions.append((new_row, new_col))
        #             if 0 <= new_row < self.board.rows and 0 <= new_col < self.board.cols and \
        #                     self.board.data[new_row][
        #                         new_col] == 'w':
        #                 break
        #     if 0 <= new_row < self.board.rows and 0 <= new_col < self.board.cols and \
        #             self.board.data[new_row][
        #                 new_col] == 'w':
        #         break
        #
        # for d_rows in range(0, -self.board.rows, -1):
        #     for d_cols in range(0, self.board.cols, 1):
        #         new_row = row + d_rows  # nova pozicija po redu
        #         new_col = col + d_cols  # nova pozicija po koloni
        #         if abs(d_rows) == abs(d_cols):
        #             if 0 <= new_row < self.board.rows and 0 <= new_col < self.board.cols and \
        #                     self.board.data[new_row][
        #                         new_col] != 'w':
        #                 new_positions.append((new_row, new_col))
        #             if 0 <= new_row < self.board.rows and 0 <= new_col < self.board.cols and \
        #                     self.board.data[new_row][
        #                         new_col] == 'w':
        #                 break
        #     if 0 <= new_row < self.board.rows and 0 <= new_col < self.board.cols and \
        #             self.board.data[new_row][
        #                 new_col] == 'w':
        #         break



        return new_positions

    def is_final_state(self):
        return self.position == self.goal_position and self.end_game

    def unique_hash(self):
        hash_code = self.position
        if len(self.collected_blue_boxes) > 0:
            for blue_box in self.collected_blue_boxes:
                hash_code = hash_code, blue_box
                if self.have_blue_boxes:
                    if len(self.collected_green_boxes) > 0:
                        for green_box in self.collected_green_boxes:
                            hash_code = hash_code, green_box

        return str(hash_code)
        # hash_code = str(self.position)
        # hash_code = hash_code + str(self.counter)
        # return hash_code

    def get_cost(self):
        x1 = self.position[0]
        y1 = self.position[1]

        x2 = self.goal_position[0]
        y2 = self.goal_position[1]

        g_distance = ((x1 - x2) ** 2 + (y1 - y2) ** 2) ** 0.5

        for fire in self.fires:
            f_distance = ((x1 - fire[0]) ** 2 + (y1 - fire[1]) ** 2) ** 0.5
            if f_distance != 0:
                if self.end_game:
                    distance = g_distance + f_distance
                else:
                    distance = g_distance + 1/f_distance

        return distance

    def get_current_cost(self):
        return self.depth
