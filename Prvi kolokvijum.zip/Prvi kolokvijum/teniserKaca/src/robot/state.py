from abc import *
from collections import deque
from copy import deepcopy
import random



class State(object):
    """
    Apstraktna klasa koja opisuje stanje pretrage.
    """

    @abstractmethod
    def __init__(self, board, parent=None, position=None, goal_position=None):
        """
        :param board: Board (tabla)
        :param parent: roditeljsko stanje
        :param position: pozicija stanja
        :param goal_position: pozicija krajnjeg stanja
        :return:
        """
        self.board = board
        self.parent = parent  # roditeljsko stanje
        if self.parent is None:  # ako nema roditeljsko stanje, onda je ovo inicijalno stanje
            self.position = board.find_position(self.get_agent_code())  # pronadji pocetnu poziciju
            self.goal_position = board.find_position(self.get_agent_goal_code())  # pronadji krajnju poziciju
        else:  # ako ima roditeljsko stanje, samo sacuvaj vrednosti parametara
            self.position = position
            self.goal_position = goal_position
        self.depth = parent.depth + 1 if parent is not None else 1  # povecaj dubinu/nivo pretrage

    def get_next_states(self):
        new_positions = self.get_legal_positions()  # dobavi moguce (legalne) sledece pozicije iz trenutne pozicije
        next_states = []
        # napravi listu mogucih sledecih stanja na osnovu mogucih sledecih pozicija
        for new_position in new_positions:
            next_state = self.__class__(self.board, self, new_position, self.goal_position)
            next_states.append(next_state)
        return next_states

    @abstractmethod
    def get_agent_code(self):
        """
        Apstraktna metoda koja treba da vrati kod agenta na tabli.
        :return: str
        """
        pass

    @abstractmethod
    def get_agent_goal_code(self):
        """
        Apstraktna metoda koja treba da vrati kod agentovog cilja na tabli.
        :return: str
        """
        pass

    @abstractmethod
    def get_legal_positions(self):
        """
        Apstraktna metoda koja treba da vrati moguce (legalne) sledece pozicije na osnovu trenutne pozicije.
        :return: list
        """
        pass

    @abstractmethod
    def is_final_state(self):
        """
        Apstraktna metoda koja treba da vrati da li je treuntno stanje zapravo zavrsno stanje.
        :return: bool
        """
        pass

    @abstractmethod
    def unique_hash(self):
        """
        Apstraktna metoda koja treba da vrati string koji je JEDINSTVEN za ovo stanje
        (u odnosu na ostala stanja).
        :return: str
        """
        pass

    @abstractmethod
    def get_cost(self):
        """
        Apstraktna metoda koja treba da vrati procenu cene
        (vrednost heuristicke funkcije) za ovo stanje.
        Koristi se za vodjene pretrage.
        :return: float
        """
        pass

    @abstractmethod
    def get_current_cost(self):
        """
        Apstraktna metoda koja treba da vrati stvarnu trenutnu cenu za ovo stanje.
        Koristi se za vodjene pretrage.
        :return: float
        """
        pass


class RobotState(State):
    def __init__(self, board, parent=None, position=None, goal_position=None, movement_type='Kralj'):
        super(self.__class__, self).__init__(board, parent, position, goal_position)
        # posle pozivanja super konstruktora, mogu se dodavati "custom" stvari vezani za stanje
        # TODO 6: prosiriti stanje sa informacijom da li je robot pokupio kutije

        self.collected_points = deque([])
        self.lost_points = deque([])
        #self.movement = movement_type
        self.result = 0
        self.positive_counter = 0
        self.negative_counter = 0
        self.end_game = False

        if parent is not None:
            self.collected_points = deepcopy(parent.collected_points)
            self.points, self.points_count = parent.points, parent.points_count

            # self.lost_points = deepcopy(parent.lost_points)
            self.negative_points, self.negative_points_count = parent.negative_points, parent.negative_points_count

            self.positive_counter = parent.positive_counter
            self.negative_counter = parent.negative_counter
            self.result = parent.result
            self.end_game = parent.end_game
        else:
            self.points, self.points_count = board.find_positions('p')
            self.negative_points, self.negative_points_count = board.find_positions('o')

        if self.end_game == False:
            for point in self.points:
                if point not in self.collected_points and self.position == point:
                    self.collected_points.append(point)
                    self.positive_counter += 1
                    self.result += 1
                    print('Rezultat: ', self.result)
                    if self.positive_counter == 4:
                        print('Krajnji rezultat: ', self.result)
                        self.end_game = True

            for n_point in self.negative_points:
                if n_point == self.position and n_point not in self.collected_points:
                    self.collected_points.append(n_point)
                    self.negative_counter += 1
                    self.result -= 1
                    print('Rezultat: ', self.negative_counter)
                    if self.negative_counter == 4:
                        print('Krajnji rezultat: ', self.result)
                        self.end_game = True

            #TEZAK TENISER
            # for lost_point in self.negative_points:
            #     if lost_point[0] == self.position[0] and lost_point[1] == self.position[1]:
            #         if lost_point not in self.lost_points:
            #             n = random.randint(0, 100)
            #             if n >= 75:
            #                 self.positive_counter += 1
            #                 self.lost_points.append(lost_point)
            #                 if self.positive_counter >= 4:
            #                     if self.positive_counter + self.negative_counter >= 2:
            #                         self.end_game = True
            #             else:
            #                 n = random.randint(0, 100)
            #                 if n >= 50:
            #                     self.positive_counter += 1
            #                     self.lost_points.append(lost_point)
            #                     if self.positive_counter >= 4:
            #                         if self.positive_counter + self.negative_counter >= 2:
            #                             self.end_game = True
            #                 else:
            #                     self.lost_points.append(lost_point)
            #                     self.negative_counter -= 1
            #                     if self.negative_counter <= -4:
            #                         if self.positive_counter + self.negative_counter <= -2:
            #                             self.end_game = True

        # if self.negative_sum == 4:
        #     self.end_game = True

    def get_agent_code(self):
        return 'r'

    def get_agent_goal_code(self):
        return 'g'

    def get_legal_positions(self):
        # d_rows (delta rows), d_cols (delta columns)
        # moguci smerovi kretanja robota (desno, levo, dole, gore)

        if self.end_game == True:
            d_rows = [0, 0, 1, -1, 1, 1, -1, -1]
            d_cols = [1, -1, 0, 0, 1, -1, 1, -1]

            row, col = self.position  # trenutno pozicija
            new_positions = []
            for d_row, d_col in zip(d_rows, d_cols):  # za sve moguce smerove
                new_row = row + d_row  # nova pozicija po redu
                new_col = col + d_col  # nova pozicija po koloni
                        # ako nova pozicija nije van table i ako nije zid ('w'), ubaci u listu legalnih pozicija
                if 0 <= new_row < self.board.rows and 0 <= new_col < self.board.cols and self.board.data[new_row][
                    new_col] != 'w':
                    new_positions.append((new_row, new_col))
        else:

            #KRETANJE KRALJICE
            row, col = self.position  # trenutno pozicija
            new_positions = []

            for d_rows in range(0, -self.board.rows, -1):
                new_row = row + d_rows  # nova pozicija po redu
                new_col = col  # nova pozicija po koloni
                # ako nova pozicija nije van table i ako nije zid ('w'), ubaci u listu legalnih pozicija
                if 0 <= new_row < self.board.rows and 0 <= new_col < self.board.cols and self.board.data[new_row][
                    new_col] != 'w':
                    new_positions.append((new_row, new_col))
                if 0 <= new_row < self.board.rows and 0 <= new_col < self.board.cols and self.board.data[new_row][
                    new_col] == 'w':
                    break
            for d_rows in range(0, self.board.rows, 1):
                new_row = row + d_rows  # nova pozicija po redu
                new_col = col  # nova pozicija po koloni
                # ako nova pozicija nije van table i ako nije zid ('w'), ubaci u listu legalnih pozicija
                if 0 <= new_row < self.board.rows and 0 <= new_col < self.board.cols and self.board.data[new_row][
                    new_col] != 'w':
                    new_positions.append((new_row, new_col))
                if 0 <= new_row < self.board.rows and 0 <= new_col < self.board.cols and self.board.data[new_row][
                    new_col] == 'w':
                    break

            for d_cols in range(0, -self.board.cols, -1):
                new_row = row  # nova pozicija po redu
                new_col = col + d_cols  # nova pozicija po koloni
                # ako nova pozicija nije van table i ako nije zid ('w'), ubaci u listu legalnih pozicija
                if 0 <= new_row < self.board.rows and 0 <= new_col < self.board.cols and self.board.data[new_row][
                    new_col] != 'w':
                    new_positions.append((new_row, new_col))
                if 0 <= new_row < self.board.rows and 0 <= new_col < self.board.cols and self.board.data[new_row][
                    new_col] == 'w':
                    break
            for d_cols in range(0, self.board.cols, 1):
                new_row = row  # nova pozicija po redu
                new_col = col + d_cols  # nova pozicija po koloni
                # ako nova pozicija nije van table i ako nije zid ('w'), ubaci u listu legalnih pozicija
                if 0 <= new_row < self.board.rows and 0 <= new_col < self.board.cols and self.board.data[new_row][
                    new_col] != 'w':
                    new_positions.append((new_row, new_col))
                if 0 <= new_row < self.board.rows and 0 <= new_col < self.board.cols and self.board.data[new_row][
                    new_col] == 'w':
                    break

            # dijagonale
            for d_rows in range(0, self.board.rows, 1):
                for d_cols in range(0, self.board.cols, 1):
                    new_row = row + d_rows  # nova pozicija po redu
                    new_col = col + d_cols  # nova pozicija po koloni
                    if abs(d_rows) == abs(d_cols):
                        if 0 <= new_row < self.board.rows and 0 <= new_col < self.board.cols and \
                                self.board.data[new_row][
                                    new_col] != 'w':
                            new_positions.append((new_row, new_col))
                        if 0 <= new_row < self.board.rows and 0 <= new_col < self.board.cols and \
                                self.board.data[new_row][
                                    new_col] == 'w':
                            break
                if 0 <= new_row < self.board.rows and 0 <= new_col < self.board.cols and \
                        self.board.data[new_row][
                            new_col] == 'w':
                    break

            for d_rows in range(0, -self.board.rows, -1):
                for d_cols in range(0, -self.board.cols, -1):
                    new_row = row + d_rows  # nova pozicija po redu
                    new_col = col + d_cols  # nova pozicija po koloni
                    if abs(d_rows) == abs(d_cols):
                        if 0 <= new_row < self.board.rows and 0 <= new_col < self.board.cols and \
                                self.board.data[new_row][
                                    new_col] != 'w':
                            new_positions.append((new_row, new_col))
                        if 0 <= new_row < self.board.rows and 0 <= new_col < self.board.cols and \
                                self.board.data[new_row][
                                    new_col] == 'w':
                            break
                if 0 <= new_row < self.board.rows and 0 <= new_col < self.board.cols and \
                        self.board.data[new_row][
                            new_col] == 'w':
                    break

            for d_rows in range(0, self.board.rows, 1):
                for d_cols in range(0, -self.board.cols, -1):
                    new_row = row + d_rows  # nova pozicija po redu
                    new_col = col + d_cols  # nova pozicija po koloni
                    if abs(d_rows) == abs(d_cols):
                        if 0 <= new_row < self.board.rows and 0 <= new_col < self.board.cols and \
                                self.board.data[new_row][
                                    new_col] != 'w':
                            new_positions.append((new_row, new_col))
                        if 0 <= new_row < self.board.rows and 0 <= new_col < self.board.cols and \
                                self.board.data[new_row][
                                    new_col] == 'w':
                            break
                if 0 <= new_row < self.board.rows and 0 <= new_col < self.board.cols and \
                        self.board.data[new_row][
                            new_col] == 'w':
                    break

            for d_rows in range(0, -self.board.rows, -1):
                for d_cols in range(0, self.board.cols, 1):
                    new_row = row + d_rows  # nova pozicija po redu
                    new_col = col + d_cols  # nova pozicija po koloni
                    if abs(d_rows) == abs(d_cols):
                        if 0 <= new_row < self.board.rows and 0 <= new_col < self.board.cols and \
                                self.board.data[new_row][
                                    new_col] != 'w':
                            new_positions.append((new_row, new_col))
                        if 0 <= new_row < self.board.rows and 0 <= new_col < self.board.cols and \
                                self.board.data[new_row][
                                    new_col] == 'w':
                            break
                if 0 <= new_row < self.board.rows and 0 <= new_col < self.board.cols and \
                        self.board.data[new_row][
                            new_col] == 'w':
                    break

        #if self.movement == 'Kralj':
        #TENISER LAKI
        # if self.end_game == True:
        #     d_rows = [0, 0, 1, -1]
        #     d_cols = [1, -1, 0, 0]
        #
        # else:
        #     d_rows = [0, 0, 0, 0, 0, 0, 1, -1]
        #     d_cols = [1, 2, 3,-1, -2, -3, 0, 0]
        #
        # row, col = self.position  # trenutno pozicija
        # new_positions = []
        # for d_row, d_col in zip(d_rows, d_cols):  # za sve moguce smerove
        #     new_row = row + d_row  # nova pozicija po redu
        #     new_col = col + d_col  # nova pozicija po koloni
        #             # ako nova pozicija nije van table i ako nije zid ('w'), ubaci u listu legalnih pozicija
        #     if 0 <= new_row < self.board.rows and 0 <= new_col < self.board.cols and self.board.data[new_row][
        #         new_col] != 'w':
        #         new_positions.append((new_row, new_col))
        #
        # return new_positions
        # elif self.movement == 'Top':
        #     row, col = self.position  # trenutno pozicija
        #     new_positions = []
        #
        #     for d_rows in range(-self.board.rows, self.board.rows):
        #         new_row = row + d_rows  # nova pozicija po redu
        #         new_col = col  # nova pozicija po koloni
        #         # ako nova pozicija nije van table i ako nije zid ('w'), ubaci u listu legalnih pozicija
        #         if 0 <= new_row < self.board.rows and 0 <= new_col < self.board.cols and self.board.data[new_row][
        #             new_col] != 'w':
        #             new_positions.append((new_row, new_col))
        #
        #     for d_cols in range(-self.board.cols, self.board.cols):
        #         new_row = row  # nova pozicija po redu
        #         new_col = col + d_cols  # nova pozicija po koloni
        #         # ako nova pozicija nije van table i ako nije zid ('w'), ubaci u listu legalnih pozicija
        #         if 0 <= new_row < self.board.rows and 0 <= new_col < self.board.cols and self.board.data[new_row][
        #             new_col] != 'w':
        #             new_positions.append((new_row, new_col))
        #elif self.movement == 'Kraljica':
            #TODO kraljica
        #elif self.movement == 'Konj':
            #TODO konj

        # portals, portals_count = self.board.find_positions('y')
        #
        # for portal in portals:
        #     if portal == self.position:
        #         for portal2 in portals:
        #             new_positions.append(portal2)
        #         break

        return new_positions

    def is_final_state(self):
       return self.position == self.goal_position and self.end_game

    def unique_hash(self):
        hash_code = self.position
        if len(self.collected_points) > 0:
            for point in self.collected_points:
                hash_code = hash_code, point
            # if len(self.lost_points) > 0:
            #     for n_point in self.lost_points:
            #         hash_code = hash_code, n_point
        return str(hash_code)

    def get_cost(self):
        x1 = self.position[0]
        y1 = self.position[1]

        x2 = self.goal_position[0]
        y2 = self.goal_position[1]

        distance = ((x1 - x2) ** 2 + (y1 - y2) ** 2) ** 0.5

        return distance

    def get_current_cost(self):
        return self.depth
