﻿## Uputstvo za dodatne zadatke

Ukoliko rešite neki od dodatnih zadataka, napravite Pull Request koji će u sebi sadržati sledeće:

* **Zaseban folder** (smisleno ime), sa svim Python skriptama koje se neophodne za izvršavanje programa (dakle, *bar* 4 skripte sa vežbi)
* U folderu napraviti README.md fajl u kom navesti ko su autori dodatnog zadatka, kratak opis dodatnog zadatka, šta je sve urađeno.
* Napravljeni folder sa svim potrebnim skriptama i podacima staviti u ovaj folder - **bonus**
