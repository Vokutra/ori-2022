from abc import *
from collections import deque
from copy import deepcopy
import numpy as np


class State(object):
    """
    Apstraktna klasa koja opisuje stanje pretrage.
    """

    @abstractmethod
    def __init__(self, board, parent=None, position=None, goal_position=None, movement_type = None):
        """
        :param board: Board (tabla)
        :param parent: roditeljsko stanje
        :param position: pozicija stanja
        :param goal_position: pozicija krajnjeg stanja
        :return:
        """
        self.board = board
        self.parent = parent  # roditeljsko stanje
        if self.parent is None:  # ako nema roditeljsko stanje, onda je ovo inicijalno stanje
            self.position = board.find_position(self.get_agent_code())  # pronadji pocetnu poziciju
            self.goal_position = board.find_position(self.get_agent_goal_code())  # pronadji krajnju poziciju
        else:  # ako ima roditeljsko stanje, samo sacuvaj vrednosti parametara
            self.position = position
            self.goal_position = goal_position
        self.depth = parent.depth + 1 if parent is not None else 1  # povecaj dubinu/nivo pretrage

    def get_next_states(self):
        new_positions = self.get_legal_positions()  # dobavi moguce (legalne) sledece pozicije iz trenutne pozicije
        next_states = []
        # napravi listu mogucih sledecih stanja na osnovu mogucih sledecih pozicija
        for new_position in new_positions:
            next_state = self.__class__(self.board, self, new_position, self.goal_position)
            next_states.append(next_state)
        return next_states

    @abstractmethod
    def get_agent_code(self):
        """
        Apstraktna metoda koja treba da vrati kod agenta na tabli.
        :return: str
        """
        pass

    @abstractmethod
    def get_agent_goal_code(self):
        """
        Apstraktna metoda koja treba da vrati kod agentovog cilja na tabli.
        :return: str
        """
        pass

    @abstractmethod
    def get_legal_positions(self):
        """
        Apstraktna metoda koja treba da vrati moguce (legalne) sledece pozicije na osnovu trenutne pozicije.
        :return: list
        """
        pass

    @abstractmethod
    def is_final_state(self):
        """
        Apstraktna metoda koja treba da vrati da li je treuntno stanje zapravo zavrsno stanje.
        :return: bool
        """
        pass

    @abstractmethod
    def unique_hash(self):
        """
        Apstraktna metoda koja treba da vrati string koji je JEDINSTVEN za ovo stanje
        (u odnosu na ostala stanja).
        :return: str
        """
        pass
    
    @abstractmethod
    def get_cost(self):
        """
        Apstraktna metoda koja treba da vrati procenu cene
        (vrednost heuristicke funkcije) za ovo stanje.
        Koristi se za vodjene pretrage.
        :return: float
        """
        pass
    
    @abstractmethod
    def get_current_cost(self):
        """
        Apstraktna metoda koja treba da vrati stvarnu trenutnu cenu za ovo stanje.
        Koristi se za vodjene pretrage.
        :return: float
        """
        pass


class RobotState(State):
    def __init__(self, board, parent=None, position=None, goal_position=None, movement_type = 'Kralj'):
        super(self.__class__, self).__init__(board, parent, position, goal_position, movement_type)
        # posle pozivanja super konstruktora, mogu se dodavati "custom" stvari vezani za stanje
        # TODO 6: prosiriti stanje sa informacijom da li je robot pokupio kutiju (sve kutije na tabli)
        self.movement = movement_type
        #TODO TEZAK Robot: doći od starta do cilja, uz prvobitno kupljenje tačno tri plave i dve narandžaste kutije.
        # Na tabli može biti proizvoljan broj plavih i narandžastih kutija. Da bi robot mogao da pokupi narandžastu kutiju, mora kod sebe imati barem jednu više plavu kutiju.
        # Robot: doći od starta do cilja, uz prvobitno kupljenje određenog broja kutija, ali uz izbegavanje polja koja predstavljaju vatru
        # (ideja je da robot radije ide putem koji je dalji od vatre).

        # if parent is None:
        #     self.start = self.board.find_position('r')
        # else:
        #     self.start = parent.start

        self.has_box = False
        self.has_blue_box = False
        self.has_green_box = False
        self.collected_blue = deque([])
        self.collected_green = deque([])

        if parent is not None:
            self.collected_green = deepcopy(parent.collected_green)
            self.collected_blue = deepcopy(parent.collected_blue)
            self.blue_boxes = parent.blue_boxes
            self.green_boxes = parent.green_boxes
            self.has_box = parent.has_box
            self.has_blue_box = parent.has_blue_box
            self.has_green_box = parent.has_green_box
            self.blue_number = parent.blue_number
            self.green_number = parent.green_number
        else:
            self.blue_boxes, self.blue_number = self.board.find_positions('b')
            self.green_boxes, self.green_number = self.board.find_positions('z')

        for box in self.blue_boxes:
            if box not in self.collected_blue and box == self.position:
                self.collected_blue.append(box)
                self.blue_number +=1

        if len(self.collected_green) < len(self.collected_blue):
            for box in self.green_boxes:
                if box not in self.collected_green and box == self.position:
                    self.collected_green.append(box)
                    self.blue_number +=1

        if len(self.collected_blue) == 3:
            self.has_blue_box = True

        if len(self.collected_green) == 2:
            self.has_green_box = True

        if self.has_blue_box and self.has_green_box:
            self.has_box = True

        # TODO SREDNJI Robot: doći od starta do cilja, uz prvobitno kupljenje tačno tri plave kutije. Na tabli može biti proizvoljan broj plavih kutija.
        # Robot: doći od starta do cilja, uz korišćenje portala (žuto polje) koji omogućavaju teleportaciju na ostale portale.
        # Kada robot prođe kroz portal (stane i "odluči" da će otići na neki drugi portal),
        # postoji šansa od 70% da će se zaista teleportovati na drugi portal, i šansa od 30% da će biti teleportovan na početnu poziciju.

        # if parent is None:
        #     self.start = self.board.find_position('r')
        # else:
        #     self.start = parent.start
        #
        # self.has_box = False
        # self.collected_boxes = deque([])
        #
        # if parent is not None:
        #     self.collected_boxes = deepcopy(parent.collected_boxes)
        #     self.all_boxes = parent.all_boxes
        #     self.boxes_number = parent.boxes_number
        #     self.has_box = parent.has_box
        # else:
        #     self.all_boxes, self.boxes_number = self.board.find_positions('b')
        #
        # for box in self.all_boxes:
        #     if box not in self.collected_boxes and box == self.position:
        #         self.collected_boxes.append(box)
        #
        #
        # if len(self.collected_boxes) == 3:
        #     self.has_box = True


        # TODO LAK Robot: doći od starta do cilja, uz prvobitno kupljenje jedne plave kutije. Kada robot pokupi kutiju može da se kreće i dijagonalno.
        # Robot: doći od starta do cilja, uz prvobitno kupljenje prvo plave, pa narandžaste kutije.

        # if self.position == self.board.find_position('b'):
        #     self.has_box = True
        # else:
        #     self.has_box = False
        #
        # if self.position== self.board.find_position('z') and self.has_box:
        #     self.has_key = True
        # else:
        #     self.has_key = False
        #
        # if parent is not None and parent.has_box:
        #     self.has_box = True
        #
        #     if self.position== self.board.find_position('z'):
        #         self.has_key= True
        #     else:
        #         self.has_key= False
        #
        # if parent is not None and parent.has_key:
        #     self.has_key = True




    def get_agent_code(self):
        return 'r'

    def get_agent_goal_code(self):
        return 'g'

    def get_legal_positions(self):
        # d_rows (delta rows), d_cols (delta columns)
        if self.blue_number >= 1:
            d_rows = [0, 0, 1, -1, -1, -1, 1, 1]
            d_cols = [1, -1, 0, 0, 1, -1, 1, -1]

            row, col = self.position  # trenutno pozicija
            new_positions = []
            for d_row, d_col in zip(d_rows, d_cols):  # za sve moguce smerove
                new_row = row + d_row  # nova pozicija po redu
                new_col = col + d_col  # nova pozicija po koloni
                # ako nova pozicija nije van table i ako nije zid ('w'), ubaci u listu legalnih pozicija
                if 0 <= new_row < self.board.rows and 0 <= new_col < self.board.cols and self.board.data[new_row][
                    new_col] != 'w':
                    new_positions.append((new_row, new_col))

        else:
        # moguci smerovi kretanja robota (desno, levo, dole, gore)
        #TODO 5: Omoguciti kretanje robota i po dijagonalama
            d_rows = [0, 0, 1, -1]
            d_cols = [1, -1, 0, 0]

            row, col = self.position  # trenutno pozicija
            new_positions = []
            for d_row, d_col in zip(d_rows, d_cols):  # za sve moguce smerove
                 new_row = row + d_row  # nova pozicija po redu
                 new_col = col + d_col  # nova pozicija po koloni
                 # ako nova pozicija nije van table i ako nije zid ('w'), ubaci u listu legalnih pozicija
                 if 0 <= new_row < self.board.rows and 0 <= new_col < self.board.cols and self.board.data[new_row][new_col] != 'w':
                    new_positions.append((new_row, new_col))
        """
        #TODO: Omoguciti kretanje ostalih figura *DODATNI*
        elif self.movement == 'Top':
        elif self.movement == 'Kraljica':
        elif self.movement == 'Konj':
        """
        # TODO 7: Portali
        portal_positions, br_portala = self.board.find_positions('p')
        if self.position in portal_positions:
            # U legalne pozicije dodati sve ostele portale sem tog na kom se trenutno nalazimo
            portal_positions.remove(self.position)
            random= np.random.rand()
            print(random)
            if random < 0.7:
                new_positions.extend(portal_positions)
            else:
                new_positions.append(self.start)

        return new_positions

    def is_final_state(self):
        #Dodata informacija i da mora da ima sve kutije da bi bio kraj
        return self.position == self.goal_position and self.has_box

    def unique_hash(self):
        hash_code = str(self.position)
        if len(self.collected_blue) > 0:
            for blue_box in self.collected_blue:
                hash_code = hash_code, blue_box
                if self.has_blue_box:
                    if len(self.collected_green) > 0:
                        for green_box in self.collected_green:
                            hash_code = hash_code, green_box
        return str(hash_code)

    def get_cost(self):
        # h_fire= 0
        # for f in self.fire_distance():
        #     h_fire += f
        # return self.goal_distance()+ 1/h_fire
        #return self.goal_distance() + 1/self.fire_distance()
        return self.goal_distance()


    def get_current_cost(self):
        return self.depth

    def goal_distance(self):
        x1 = self.position[0]
        y1 = self.position[1]

        x2 = self.goal_position[0]
        y2 = self.goal_position[1]

        distance = ((x1 - x2) ** 2 + (y1 - y2) ** 2) ** 0.5

        return distance

    # def fire_distance(self):
    #     fire = []
    #     for f in self.board.find_positions('f'):
    #         pos = ((self.position[0] - f[0]) ** 2 + (self.position[1] - f[1]) ** 2) ** 0.5
    #         fire.append(pos)
    #         if pos != 0:
    #             fire.append(5 / pos)
    #     return fire

    def fire_distance(self):
        f = self.board.find_position('f')
        pos = ((self.position[0] - f[0]) ** 2 + (self.position[1] - f[1]) ** 2) ** 0.5

        return pos

    # def box_distance(self):
    #     for box in self.board.find_positions('b'):
    #         box_pos = self.board.find_position("b")
    #         return ((self.position[0] - box_pos[0]) ** 2 + (self.position[1] - box_pos[1]) ** 2) ** 0.5
    #

