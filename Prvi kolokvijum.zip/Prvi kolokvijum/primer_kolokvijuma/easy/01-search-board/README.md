## Vežba 1 - Pretrage

Otvoriti datoteku **01-search-board.ipynb**.
