from abc import *
import numpy as np
import copy


class State(object):
    """
    Apstraktna klasa koja opisuje stanje pretrage.
    """

    @abstractmethod
    def __init__(self, board, parent=None, position=None, goal_position=None):
        """
        :param board: Board (tabla)
        :param parent: roditeljsko stanje
        :param position: pozicija stanja
        :param goal_position: pozicija krajnjeg stanja
        :return:
        """
        self.board = board
        self.parent = parent  # roditeljsko stanje
        if self.parent is None:  # ako nema roditeljsko stanje, onda je ovo inicijalno stanje
            self.position = board.find_position(self.get_agent_code())  # pronadji pocetnu poziciju
            self.goal_position = board.find_position(self.get_agent_goal_code())  # pronadji krajnju poziciju
        else:  # ako ima roditeljsko stanje, samo sacuvaj vrednosti parametara
            self.position = position
            self.goal_position = goal_position
        self.depth = parent.depth + 1 if parent is not None else 1  # povecaj dubinu/nivo pretrage

    def get_next_states(self):
        new_positions = self.get_legal_positions()  # dobavi moguce (legalne) sledece pozicije iz trenutne pozicije
        next_states = []
        # napravi listu mogucih sledecih stanja na osnovu mogucih sledecih pozicija
        for new_position in new_positions:
            next_state = self.__class__(self.board, self, new_position, self.goal_position)
            next_states.append(next_state)
        return next_states

    @abstractmethod
    def get_agent_code(self):
        """
        Apstraktna metoda koja treba da vrati kod agenta na tabli.
        :return: str
        """
        pass

    @abstractmethod
    def get_agent_goal_code(self):
        """
        Apstraktna metoda koja treba da vrati kod agentovog cilja na tabli.
        :return: str
        """
        pass

    @abstractmethod
    def get_legal_positions(self):
        """
        Apstraktna metoda koja treba da vrati moguce (legalne) sledece pozicije na osnovu trenutne pozicije.
        :return: list
        """
        pass

    @abstractmethod
    def is_final_state(self):
        """
        Apstraktna metoda koja treba da vrati da li je treuntno stanje zapravo zavrsno stanje.
        :return: bool
        """
        pass

    @abstractmethod
    def unique_hash(self):
        """
        Apstraktna metoda koja treba da vrati string koji je JEDINSTVEN za ovo stanje
        (u odnosu na ostala stanja).
        :return: str
        """
        pass

    @abstractmethod
    def get_cost(self):
        """
        Apstraktna metoda koja treba da vrati procenu cene
        (vrednost heuristicke funkcije) za ovo stanje.
        Koristi se za vodjene pretrage.
        :return: float
        """
        pass

    @abstractmethod
    def get_current_cost(self):
        """
        Apstraktna metoda koja treba da vrati stvarnu trenutnu cenu za ovo stanje.
        Koristi se za vodjene pretrage.
        :return: float
        """
        pass


class RobotState(State):
    def __init__(self, board, parent=None, position=None, goal_position=None):
        super(self.__class__, self).__init__(board, parent, position, goal_position)
        self.all_purple_boxes = self.board.find_positions('p')
        self.all_yellow_boxes = self.board.find_positions('y')
        self.has_box = False
        if parent is not None:
            self.points_cnt = copy.deepcopy(parent.points_cnt)
            self.picked_boxes = set(parent.picked_boxes)
            # self.picked_boxes_y = set(parent.picked_boxes_y)
            # self.picked_boxes_p = set(parent.picked_boxes_p)
        else:
            self.points_cnt = 0
            # self.picked_boxes_y = set()
            # self.picked_boxes_p = set()
            self.picked_boxes = set()
        if parent is not None and parent.has_box:
            self.has_box = True
        # another way to do this
        # if self.position in self.all_purple_boxes and self.position not in self.picked_boxes_p:
        #     self.picked_boxes_p.add(self.position)
        # if self.position in self.all_yellow_boxes and self.position not in self.picked_boxes_y:
        #     self.picked_boxes_y.add(self.position)
        if self.position in self.all_purple_boxes and self.position not in self.picked_boxes:
            self.points_cnt += 1
            self.picked_boxes.add(self.position)
            print(self.points_cnt)
        if self.position in self.all_yellow_boxes and self.position not in self.picked_boxes:
            self.points_cnt -= 1
            self.picked_boxes.add(self.position)
            print(self.points_cnt)
        if self.points_cnt == 4 or self.points_cnt == -4:
            self.has_box = True
        if self.position == self.board.find_position('g') and self.has_box:
            if self.points_cnt == 4:
                print("Player won!")
            if self.points_cnt == -4:
                print("Player lose!")
        # print("Result:" + len(self.picked_boxes_p)-len(self.picked_boxes_y))
        # if len(self.picked_boxes_y) == 4 or len(self.picked_boxes_p) == 4:
        #     self.has_box = True
        # if parent is not None and parent.has_box:
        #     self.has_box = True
        # if self.position == self.board.find_position('g') and self.has_box:
        #     if len(self.picked_boxes_p) == 4:
        #         print("Player won!")
        #     if len(self.picked_boxes_y) == 4:
        #         print("Player lose!")

    def moves_before_finish(self):
        deltas = [(0, 1), (0, -1)]  # desno,levo
        validPositions = []
        x0, y0 = self.position
        for d in deltas:
            for i in range(1, 4):
                new_col = y0 + d[1] * i
                if 0 <= new_col < self.board.cols and self.board.data[x0][
                    new_col] != 'w':
                    validPositions.append((x0, new_col))
        if 0 <= x0 + 1 < self.board.rows and self.board.data[x0 + 1][
            y0] != 'w':
            validPositions.append((x0 + 1, y0))
            validPositions.append((x0 - 1, y0))
        return validPositions

    def get_agent_code(self):
        return 'r'

    def get_agent_goal_code(self):
        return 'g'

    def get_diagonal_movement(self):
        d_rows = [0, 0, 1, -1, 1, 1, -1, -1]
        d_cols = [1, -1, 0, 0, 1, -1, -1, 1]
        return d_rows, d_cols

    def rook_move(self):
        deltas = [(-1, 0), (0, -1), (1, 0), (0, 1)]  # up,left,down,right
        x0, y0 = self.position
        validPositions = []
        for d in deltas:
            for i in range(1, 20):
                new_row = x0 + d[0] * i
                new_col = y0 + d[1] * i
                if 0 <= new_row < self.board.rows and 0 <= new_col < self.board.cols and self.board.data[new_row][
                    new_col] != 'w':
                    validPositions.append((new_row, new_col))
        return validPositions

    def bishop_move(self):
        deltas = [(-1, 1), (-1, -1), (1, -1), (1, 1)]
        x0, y0 = self.position
        validPositions = []
        for d in deltas:
            for i in range(1, 20):
                new_row = x0 + d[0] * i
                new_col = y0 + d[1] * i
                if 0 <= new_row < self.board.rows and 0 <= new_col < self.board.cols and self.board.data[new_row][
                    new_col] != 'w':
                    validPositions.append((new_row, new_col))
        return validPositions

    def queen_move(self):
        new_positions = []
        for (kx, ky) in self.rook_move():
            new_positions.append((kx, ky))

        for (kx, ky) in self.bishop_move():
            new_positions.append((kx, ky))
        return new_positions

    def get_legal_positions(self):
        # d_rows (delta rows), d_cols (delta columns)
        # moguci smerovi kretanja robota (desno, levo, dole, gore)
        # new_positions = self.queen_move()
        new_positions = self.queen_move()
        return new_positions

    def is_final_state(self):
        return self.position == self.goal_position and self.has_box

    def unique_hash(self):
        #arr = str([box for box in self.picked_boxes_y])
        #arr1 = str([box for box in self.picked_boxes_p])
        #return str(self.position) + str(arr) + str(arr1) + str(self.has_box)
        arr = str([box for box in self.picked_boxes])
        return str(self.position) + str(arr) + str(self.points_cnt) + str(self.has_box)

    def get_current_cost(self):
        return self.depth

    def goal_distance(self):
        return ((self.position[0] - self.goal_position[0]) ** 2 + (
                self.position[1] - self.goal_position[1]) ** 2) ** 0.5

    def get_cost(self):
        # euclid distance
        return self.goal_distance()
