from abc import *
import numpy as np


class State(object):
    """
    Apstraktna klasa koja opisuje stanje pretrage.
    """

    @abstractmethod
    def __init__(self, board, parent=None, position=None, goal_position=None):
        """
        :param board: Board (tabla)
        :param parent: roditeljsko stanje
        :param position: pozicija stanja
        :param goal_position: pozicija krajnjeg stanja
        :return:
        """
        self.board = board
        self.parent = parent  # roditeljsko stanje
        if self.parent is None:  # ako nema roditeljsko stanje, onda je ovo inicijalno stanje
            self.position = board.find_position(self.get_agent_code())  # pronadji pocetnu poziciju
            self.goal_position = board.find_position(self.get_agent_goal_code())  # pronadji krajnju poziciju
        else:  # ako ima roditeljsko stanje, samo sacuvaj vrednosti parametara
            self.position = position
            self.goal_position = goal_position
        self.depth = parent.depth + 1 if parent is not None else 1  # povecaj dubinu/nivo pretrage

    def get_next_states(self):
        new_positions = self.get_legal_positions()  # dobavi moguce (legalne) sledece pozicije iz trenutne pozicije
        next_states = []
        # napravi listu mogucih sledecih stanja na osnovu mogucih sledecih pozicija
        for new_position in new_positions:
            next_state = self.__class__(self.board, self, new_position, self.goal_position)
            next_states.append(next_state)
        return next_states

    @abstractmethod
    def get_agent_code(self):
        """
        Apstraktna metoda koja treba da vrati kod agenta na tabli.
        :return: str
        """
        pass

    @abstractmethod
    def get_agent_goal_code(self):
        """
        Apstraktna metoda koja treba da vrati kod agentovog cilja na tabli.
        :return: str
        """
        pass

    @abstractmethod
    def get_legal_positions(self):
        """
        Apstraktna metoda koja treba da vrati moguce (legalne) sledece pozicije na osnovu trenutne pozicije.
        :return: list
        """
        pass

    @abstractmethod
    def is_final_state(self):
        """
        Apstraktna metoda koja treba da vrati da li je treuntno stanje zapravo zavrsno stanje.
        :return: bool
        """
        pass

    @abstractmethod
    def unique_hash(self):
        """
        Apstraktna metoda koja treba da vrati string koji je JEDINSTVEN za ovo stanje
        (u odnosu na ostala stanja).
        :return: str
        """
        pass

    @abstractmethod
    def get_cost(self):
        """
        Apstraktna metoda koja treba da vrati procenu cene
        (vrednost heuristicke funkcije) za ovo stanje.
        Koristi se za vodjene pretrage.
        :return: float
        """
        pass

    @abstractmethod
    def get_current_cost(self):
        """
        Apstraktna metoda koja treba da vrati stvarnu trenutnu cenu za ovo stanje.
        Koristi se za vodjene pretrage.
        :return: float
        """
        pass


class RobotState(State):
    def __init__(self, board, parent=None, position=None, goal_position=None):
        super(self.__class__, self).__init__(board, parent, position, goal_position)
        # posle pozivanja super konstruktora, mogu se dodavati "custom" stvari vezani za stanje
        # TODO 6: prosiriti stanje sa informacijom da li je robot pokupio kutiju
        # TODO :LAK
        # self.has_box = True if self.position == self.board.find_position('b') else False
        # # self.has_box1 = True if self.position == self.board.find_position('y') and self.has_box else False
        # self.has_box1 = False
        # if parent is not None and parent.has_box:
        #     self.has_box = True
        #     self.has_box1 = True if self.position == self.board.find_position('y') else False
        # if parent is not None and parent.has_box1:
        #     self.has_box1 = True
        # TODO SREDNJI 0
        # all_boxes = self.board.find_positions('b')
        # self.has_box = False;
        # self.collected_boxes = set()
        # if self.parent is not None:                                             # ako je u pitanju koren stabla,
        #     self.collected_boxes = set(self.parent.collected_boxes)
        # for box in all_boxes:
        #     if box not in self.collected_boxes and box == self.position:
        #         self.collected_boxes.add(box)
        #         break
        # if len(self.collected_boxes) == 3:
        #     self.has_box = True
        # if self.parent is not None and parent.has_box:
        #     self.has_box = True
        # TODO TEZAK 0
        # if parent is None:
        #     self.start = self.position
        # else:
        #     self.start = self.parent.start
        # self.has_box = False
        # if self.parent is not None:
        #     self.collected_blue = set(self.parent.collected_blue)
        #     self.collected_yellow = set(self.parent.collected_yellow)
        # else:
        #     self.collected_blue = set()
        #     self.collected_yellow = set()
        # boxes_b = self.board.find_positions('b')
        # boxes_y = self.board.find_positions('y')
        # for box in boxes_b:
        #     if box not in self.collected_blue and box == self.position:
        #         self.collected_blue.add(box)
        #         break
        # if len(self.collected_yellow) < len(self.collected_blue):
        #     for box in boxes_y:
        #         if box not in self.collected_yellow and box == self.position:
        #             self.collected_yellow.add(box)
        #             break
        # if len(self.collected_yellow) == 2 and len(self.collected_blue) == 3:
        #     self.has_box = True
        # if parent is not None and parent.has_box:
        #     self.has_box = True


    def get_agent_code(self):
        return 'r'

    def get_agent_goal_code(self):
        return 'g'

    def get_diagonal_movement(self):
        d_rows = [0, 0, 1, -1, 1, 1, -1, -1]
        d_cols = [1, -1, 0, 0, 1, -1, -1, 1]
        return d_rows, d_cols

    def get_legal_positions(self):
        # d_rows (delta rows), d_cols (delta columns)
        # moguci smerovi kretanja robota (desno, levo, dole, gore)
        d_rows = [0, 0, 1, -1]
        d_cols = [1, -1, 0, 0]

        row, col = self.position  # trenutno pozicija
        new_positions = []

        for d_row, d_col in zip(d_rows, d_cols):  # za sve moguce smerove
            new_row = row + d_row  # nova pozicija po redu
            new_col = col + d_col  # nova pozicija po koloni
            # ako nova pozicija nije van table i ako nije zid ('w'), ubaci u listu legalnih pozicija
            if 0 <= new_row < self.board.rows and 0 <= new_col < self.board.cols and self.board.data[new_row][
                new_col] != 'w':
                new_positions.append((new_row, new_col))
        # TODO:SREDNJI
        # portals = self.board.find_positions('y')
        # if self.position in portals:  # ako smo na portalu, dodaj za susede i
        #     # new_positions.clear()
        #     for p in portals:
        #         if np.random.rand() < 0.7:
        #             new_positions.append(p)
        #         else:
        #             new_positions.append(self.start)
        return new_positions

    def is_final_state(self):
        # TODO:LAK-Srednji
        # return self.position == self.goal_position and self.has_box1
        return self.position == self.goal_position

    def unique_hash(self):
        # TODO:LAK
        # return str(self.position) + str(self.has_box) + str(self.has_box1)
        # TODO: Tezak
        # arr = str([box for box in self.collected_blue])
        # arr1 = str([box for box in self.collected_yellow])
        # return str(self.position) + str(arr) + str(arr1) + str(self.has_box)
        return str(self.position)

    def get_current_cost(self):
        return self.depth

    def goal_distance(self):
        return ((self.position[0] - self.goal_position[0]) ** 2 + (
                self.position[1] - self.goal_position[1]) ** 2) ** 0.5

    def fire_distance(self):
        fire = []
        for f in self.board.find_positions('p'):
            pos = ((self.position[0] - f[0]) ** 2 + (self.position[1] - f[1]) ** 2) ** 0.5
            if pos != 0:
                fire.append(5/pos)
        return fire


    def box_distance(self):
        if len(self.board.find_all_elems("b")) != 0:
            box_pos = self.board.find_position("b")
            return ((self.position[0] - box_pos[0]) ** 2 + (self.position[1] - box_pos[1]) ** 2) ** 0.5
        else:
            return 0

    def get_cost(self):
        # euclid distance
        h_fire = 0
        for f in self.fire_distance():
            h_fire += f
        return self.goal_distance()+ h_fire

        # manhattan distance
        # return abs(self.position[0]-self.goal_position[0]) + abs(self.position[1]-self.goal_position[1])
        # metoda za razvijanje cvora
